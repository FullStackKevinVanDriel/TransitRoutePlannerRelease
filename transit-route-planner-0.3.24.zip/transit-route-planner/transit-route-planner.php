<?php
/**
 * Plugin Name: Transit Route Planner
 * Version: 0.3.24
 * Description: A transit route planner using Google Maps transit.
 * Author: Kevin A. VanDriel
 * Author URI: https://vandromeda.com
 * Plugin URI: https://vandromeda.com/transit-route-planner/
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: transit-route-planner
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.9
 * Requires PHP: 8.0
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

// Single source of truth for version - update this constant only
define('TRP_VERSION', '0.3.24');

// Enqueue assets
function trp_enqueue_assets() {
    // Enqueue minified JavaScript with file-based cache busting
    $js_files = glob(plugin_dir_path(__FILE__) . 'dist/static/js/main.*.js');
    if (empty($js_files)) {
        // Fallback to non-hashed filename
        $js_path = plugin_dir_path(__FILE__) . 'dist/static/js/main.js';
        if (!file_exists($js_path)) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('Transit Route Planner: No JavaScript file found in dist/static/js'); }
            return;
        }
    } else {
        $js_path = $js_files[0];
    }
    $js_file = basename($js_path);
    $js_version = filemtime($js_path);
    wp_enqueue_script(
        'trp-react-app',
        plugins_url("/dist/static/js/$js_file", __FILE__),
        [],
        $js_version,
        true
    );

    // Enqueue minified CSS with file-based cache busting
    $css_files = glob(plugin_dir_path(__FILE__) . 'dist/static/css/main.*.css');
    if (empty($css_files)) {
        // Fallback to non-hashed filename
        $css_path = plugin_dir_path(__FILE__) . 'dist/static/css/main.css';
        if (!file_exists($css_path)) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('Transit Route Planner: No CSS file found in dist/static/css'); }
            return;
        }
    } else {
        $css_path = $css_files[0];
    }
    $css_file = basename($css_path);
    $css_version = filemtime($css_path);
    wp_enqueue_style(
        'trp-styles',
        plugins_url("/dist/static/css/$css_file", __FILE__),
        [],
        $css_version
    );

    // Localize settings for the React app
    $settings = get_option('trp_settings', []);
    $license_status = get_option('trp_license_status', []);
    $api_key = isset($settings['google_maps_api_key']) ? sanitize_text_field($settings['google_maps_api_key']) : '';
    $trp_settings = [
        'mapsAPIUrlProd' => $api_key ? rest_url('trp/v1/autocomplete') : '',
        'geocodeAPIUrlProd' => $api_key ? rest_url('trp/v1/geocode') : '',
        'directionsAPIUrlProd' => $api_key ? rest_url('trp/v1/directions') : '', // Added for Directions API
        'center' => [
            'lat' => isset($settings['center_lat']) && is_numeric($settings['center_lat']) ? floatval($settings['center_lat']) : 46.6621,
            'lng' => isset($settings['center_lng']) && is_numeric($settings['center_lng']) ? floatval($settings['center_lng']) : -122.964,
        ],
        'radius' => isset($settings['radius']) && is_numeric($settings['radius']) ? floatval($settings['radius']) : 50000.0,
        'countryRestriction' => isset($settings['country_restriction']) ? sanitize_text_field($settings['country_restriction']) : 'us',
        'travelMode' => isset($settings['travel_mode']) ? sanitize_text_field($settings['travel_mode']) : 'TRANSIT',
        'zoomLevel' => isset($settings['zoom_level']) && is_numeric($settings['zoom_level']) ? intval($settings['zoom_level']) : 11,
        'version' => TRP_VERSION,
        // License settings
        'licenseKey' => isset($settings['license_key']) ? sanitize_text_field($settings['license_key']) : '',
        'licenseValidated' => !empty($license_status['is_pro']),
        'licenseTier' => isset($license_status['tier']) ? sanitize_text_field($license_status['tier']) : 'free',
        // Coverage area display setting (use 1/0 for wp_localize_script compatibility)
        'showRectangularCoverageArea' => !empty($settings['show_rectangle_coverage_area']) ? 1 : 0,
        // REST API settings for frontend
        'restUrl' => rest_url('trp/v1/'),
        'nonce' => wp_create_nonce('wp_rest'),
    ];

    // Validate zoomLevel
    if ($trp_settings['zoomLevel'] < 1 || $trp_settings['zoomLevel'] > 20) {
        $trp_settings['zoomLevel'] = 11;
    }

    // Use explicit corner coordinates if available, otherwise compute from center and radius
    $has_explicit_corners = isset($settings['nw_lat']) && isset($settings['nw_lng']) &&
                            isset($settings['ne_lat']) && isset($settings['ne_lng']) &&
                            isset($settings['sw_lat']) && isset($settings['sw_lng']) &&
                            isset($settings['se_lat']) && isset($settings['se_lng']) &&
                            is_numeric($settings['nw_lat']) && is_numeric($settings['nw_lng']);

    if ($has_explicit_corners) {
        // Use explicit corner coordinates from settings
        $trp_settings['regionCorners'] = [
            'northwest' => [
                'lat' => floatval($settings['nw_lat']),
                'lng' => floatval($settings['nw_lng']),
            ],
            'northeast' => [
                'lat' => floatval($settings['ne_lat']),
                'lng' => floatval($settings['ne_lng']),
            ],
            'southwest' => [
                'lat' => floatval($settings['sw_lat']),
                'lng' => floatval($settings['sw_lng']),
            ],
            'southeast' => [
                'lat' => floatval($settings['se_lat']),
                'lng' => floatval($settings['se_lng']),
            ],
        ];
    } else {
        // Compute regionCorners from center and radius
        $center_lat = $trp_settings['center']['lat'];
        $center_lng = $trp_settings['center']['lng'];
        $radius = $trp_settings['radius'];

        // Convert radius from meters to degrees
        // 1 degree latitude ≈ 111,194 meters
        $lat_to_meters = 111194;
        $lat_offset = $radius / $lat_to_meters;

        // Longitude offset depends on latitude (cos adjustment)
        $lng_to_meters = $lat_to_meters * cos(deg2rad($center_lat));
        $lng_offset = $radius / $lng_to_meters;

        $trp_settings['regionCorners'] = [
            'northwest' => [
                'lat' => $center_lat + $lat_offset,
                'lng' => $center_lng - $lng_offset,
            ],
            'northeast' => [
                'lat' => $center_lat + $lat_offset,
                'lng' => $center_lng + $lng_offset,
            ],
            'southwest' => [
                'lat' => $center_lat - $lat_offset,
                'lng' => $center_lng - $lng_offset,
            ],
            'southeast' => [
                'lat' => $center_lat - $lat_offset,
                'lng' => $center_lng + $lng_offset,
            ],
        ];
    }

    // Store settings for later use in shortcode (not using wp_localize_script to bypass LiteSpeed Cache)
    global $trp_settings_data;
    $trp_settings_data = $trp_settings;
}
add_action('wp_enqueue_scripts', 'trp_enqueue_assets');

// Register REST API routes
add_action('rest_api_init', function () {
    // Proxy Google Maps JavaScript API
    register_rest_route('trp/v1', '/proxy-google-maps', [
        'methods' => 'GET',
        'callback' => 'trp_handle_proxy_google_maps',
        'permission_callback' => '__return_true',
    ]);

    // Directions API endpoint
    register_rest_route('trp/v1', '/directions', [
        'methods' => 'POST',
        'callback' => 'trp_handle_directions',
        'permission_callback' => '__return_true',
    ]);

    // Autocomplete endpoint (replaces existing)
    register_rest_route('trp/v1', '/autocomplete', [
        'methods' => 'POST',
        'callback' => 'trp_handle_autocomplete',
        'permission_callback' => '__return_true',
    ]);

    // Geocode endpoint
    register_rest_route('trp/v1', '/geocode', [
        'methods' => 'GET',
        'callback' => 'trp_handle_geocode',
        'permission_callback' => '__return_true',
    ]);

    // Settings: Update coverage area display
    register_rest_route('trp/v1', '/settings/coverage-area', [
        'methods' => 'POST',
        'callback' => 'trp_handle_update_coverage_area',
        'permission_callback' => '__return_true', // Anyone can toggle, value saved per-site
    ]);

    // Admin: Set password
    register_rest_route('trp/v1', '/admin/set-password', [
        'methods' => 'POST',
        'callback' => 'trp_handle_set_password',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: Verify password (unlock API key)
    register_rest_route('trp/v1', '/admin/verify-password', [
        'methods' => 'POST',
        'callback' => 'trp_handle_verify_password',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: Lock API key
    register_rest_route('trp/v1', '/admin/lock-api-key', [
        'methods' => 'POST',
        'callback' => 'trp_handle_lock_api_key',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: Save API key
    register_rest_route('trp/v1', '/admin/save-api-key', [
        'methods' => 'POST',
        'callback' => 'trp_handle_save_api_key',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: Set test API key
    register_rest_route('trp/v1', '/admin/set-test-key', [
        'methods' => 'POST',
        'callback' => 'trp_handle_set_test_key',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: Clear test API key
    register_rest_route('trp/v1', '/admin/clear-test-key', [
        'methods' => 'POST',
        'callback' => 'trp_handle_clear_test_key',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Admin: AI coordinate lookup
    register_rest_route('trp/v1', '/admin/ai-coordinates', [
        'methods' => 'POST',
        'callback' => 'trp_handle_ai_coordinates',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        },
    ]);

    // Frameless settings page for embedding
    register_rest_route('trp/v1', '/settings-frame', [
        'methods' => 'GET',
        'callback' => 'trp_render_settings_frame',
        'permission_callback' => '__return_true',
    ]);
});

// Render frameless settings page for iframe embedding
function trp_render_settings_frame() {
    $settings = get_option('trp_settings', []);
    $api_key = isset($settings['google_maps_api_key']) ? $settings['google_maps_api_key'] : '';

    // Get current settings values
    $nw_lat = isset($settings['nw_lat']) ? $settings['nw_lat'] : '46.7667';
    $nw_lng = isset($settings['nw_lng']) ? $settings['nw_lng'] : '-123.2167';
    $ne_lat = isset($settings['ne_lat']) ? $settings['ne_lat'] : '46.7667';
    $ne_lng = isset($settings['ne_lng']) ? $settings['ne_lng'] : '-121.3167';
    $sw_lat = isset($settings['sw_lat']) ? $settings['sw_lat'] : '46.3333';
    $sw_lng = isset($settings['sw_lng']) ? $settings['sw_lng'] : '-123.2167';
    $se_lat = isset($settings['se_lat']) ? $settings['se_lat'] : '46.3333';
    $se_lng = isset($settings['se_lng']) ? $settings['se_lng'] : '-121.3167';
    $country = isset($settings['country_restriction']) ? $settings['country_restriction'] : 'us';

    $masked_key = !empty($api_key) ? substr($api_key, 0, 8) . '****' . substr($api_key, -4) : '(not configured)';

    header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transit Route Planner Settings</title>
    <?php if (!empty($api_key)): ?>
    <?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Standalone HTML page rendered in iframe, wp_enqueue_script not available ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($api_key); ?>&libraries=places&loading=async"></script>
    <?php endif; ?>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8f9fa;
            padding: 20px;
            color: #333;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #1a1a1a;
        }
        h2 {
            font-size: 18px;
            margin: 24px 0 12px 0;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 8px;
        }
        .settings-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .field-row {
            margin-bottom: 16px;
        }
        .field-row label {
            display: block;
            font-weight: 500;
            margin-bottom: 6px;
        }
        .field-row input[type="text"],
        .field-row input[type="number"] {
            width: 100%;
            max-width: 300px;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }
        .field-row input:focus {
            outline: none;
            border-color: #667eea;
        }
        .field-row .description {
            font-size: 13px;
            color: #666;
            margin-top: 4px;
        }
        .api-key-display {
            font-family: monospace;
            background: #f0f0f0;
            padding: 8px 12px;
            border-radius: 4px;
            display: inline-block;
        }
        .coord-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            max-width: 500px;
        }
        .coord-box {
            background: #f8fafc;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
        }
        .coord-box strong {
            display: block;
            margin-bottom: 8px;
            color: #667eea;
        }
        .coord-box input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 6px;
        }
        #settings-map {
            width: 100%;
            height: 300px;
            border-radius: 8px;
            margin-bottom: 16px;
            background: #e2e8f0;
        }
        .save-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
        }
        .save-btn:hover {
            opacity: 0.9;
        }
        .save-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .status-message {
            padding: 12px;
            border-radius: 6px;
            margin-top: 16px;
            display: none;
        }
        .status-message.success {
            background: #d4edda;
            color: #155724;
            display: block;
        }
        .status-message.error {
            background: #f8d7da;
            color: #721c24;
            display: block;
        }
    </style>
</head>
<body>
    <h1>Transit Route Planner Settings</h1>

    <div class="settings-section">
        <h2>API Configuration</h2>
        <div class="field-row">
            <label>Google Maps API Key</label>
            <div class="api-key-display"><?php echo esc_html($masked_key); ?></div>
            <p class="description">API key is configured in WordPress admin for security.</p>
        </div>
    </div>

    <div class="settings-section">
        <h2>Service Area</h2>
        <p class="description" style="margin-bottom: 16px;">Define the transit coverage area. Drag the rectangle or edit coordinates.</p>

        <?php if (!empty($api_key)): ?>
        <div id="settings-map"></div>
        <?php endif; ?>

        <div class="coord-grid">
            <div class="coord-box">
                <strong>Northwest</strong>
                <input type="number" step="any" id="nw_lat" value="<?php echo esc_attr($nw_lat); ?>" placeholder="Latitude" >
                <input type="number" step="any" id="nw_lng" value="<?php echo esc_attr($nw_lng); ?>" placeholder="Longitude" >
            </div>
            <div class="coord-box">
                <strong>Northeast</strong>
                <input type="number" step="any" id="ne_lat" value="<?php echo esc_attr($ne_lat); ?>" placeholder="Latitude" >
                <input type="number" step="any" id="ne_lng" value="<?php echo esc_attr($ne_lng); ?>" placeholder="Longitude" >
            </div>
            <div class="coord-box">
                <strong>Southwest</strong>
                <input type="number" step="any" id="sw_lat" value="<?php echo esc_attr($sw_lat); ?>" placeholder="Latitude" >
                <input type="number" step="any" id="sw_lng" value="<?php echo esc_attr($sw_lng); ?>" placeholder="Longitude" >
            </div>
            <div class="coord-box">
                <strong>Southeast</strong>
                <input type="number" step="any" id="se_lat" value="<?php echo esc_attr($se_lat); ?>" placeholder="Latitude" >
                <input type="number" step="any" id="se_lng" value="<?php echo esc_attr($se_lng); ?>" placeholder="Longitude" >
            </div>
        </div>
    </div>

    <div class="settings-section">
        <h2>Search Options</h2>
        <div class="field-row">
            <label for="country">Limit Searches To</label>
            <input type="text" id="country" value="<?php echo esc_attr($country); ?>" style="max-width: 100px;" >
            <p class="description">Country code (e.g., 'us' for United States)</p>
        </div>
    </div>

    <button type="button" class="save-btn" onclick="saveSettings()">Save Settings</button>
    <div id="status-message" class="status-message"></div>

    <script>
        var map, rectangle;

        function initMap() {
            if (typeof google === 'undefined' || typeof google.maps === 'undefined') {
                setTimeout(initMap, 100);
                return;
            }

            var nwLat = parseFloat(document.getElementById('nw_lat').value);
            var nwLng = parseFloat(document.getElementById('nw_lng').value);
            var seLat = parseFloat(document.getElementById('se_lat').value);
            var seLng = parseFloat(document.getElementById('se_lng').value);

            var center = {
                lat: (nwLat + seLat) / 2,
                lng: (nwLng + seLng) / 2
            };

            map = new google.maps.Map(document.getElementById('settings-map'), {
                center: center,
                zoom: 8,
                mapTypeControl: false,
                streetViewControl: false
            });

            var bounds = {
                north: nwLat,
                south: seLat,
                east: seLng,
                west: nwLng
            };

            rectangle = new google.maps.Rectangle({
                bounds: bounds,
                editable: true,
                draggable: true,
                strokeColor: '#667eea',
                strokeOpacity: 0.9,
                strokeWeight: 2,
                fillColor: '#667eea',
                fillOpacity: 0.15
            });
            rectangle.setMap(map);
            map.fitBounds(bounds);

            google.maps.event.addListener(rectangle, 'bounds_changed', function() {
                var b = rectangle.getBounds();
                var ne = b.getNorthEast();
                var sw = b.getSouthWest();

                document.getElementById('nw_lat').value = ne.lat().toFixed(4);
                document.getElementById('nw_lng').value = sw.lng().toFixed(4);
                document.getElementById('ne_lat').value = ne.lat().toFixed(4);
                document.getElementById('ne_lng').value = ne.lng().toFixed(4);
                document.getElementById('sw_lat').value = sw.lat().toFixed(4);
                document.getElementById('sw_lng').value = sw.lng().toFixed(4);
                document.getElementById('se_lat').value = sw.lat().toFixed(4);
                document.getElementById('se_lng').value = ne.lng().toFixed(4);
            });
        }

        function saveSettings() {
            var btn = document.querySelector('.save-btn');
            var status = document.getElementById('status-message');
            btn.disabled = true;
            btn.textContent = 'Saving...';

            var data = {
                nw_lat: document.getElementById('nw_lat').value,
                nw_lng: document.getElementById('nw_lng').value,
                ne_lat: document.getElementById('ne_lat').value,
                ne_lng: document.getElementById('ne_lng').value,
                sw_lat: document.getElementById('sw_lat').value,
                sw_lng: document.getElementById('sw_lng').value,
                se_lat: document.getElementById('se_lat').value,
                se_lng: document.getElementById('se_lng').value,
                country_restriction: document.getElementById('country').value
            };

            fetch('<?php echo esc_url(rest_url('trp/v1/settings-save')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': '<?php echo esc_attr(wp_create_nonce('wp_rest')); ?>'
                },
                body: JSON.stringify(data)
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                btn.disabled = false;
                btn.textContent = 'Save Settings';
                if (res.success) {
                    status.className = 'status-message success';
                    status.textContent = 'Settings saved successfully!';
                } else {
                    status.className = 'status-message error';
                    status.textContent = res.message || 'Failed to save settings.';
                }
            })
            .catch(function(err) {
                btn.disabled = false;
                btn.textContent = 'Save Settings';
                status.className = 'status-message error';
                status.textContent = 'Error: ' + err.message;
            });
        }

        // Init map when ready
        if (document.getElementById('settings-map')) {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initMap);
            } else {
                initMap();
            }
        }
    </script>
</body>
</html>
    <?php
    exit;
}

// Handle saving settings from frameless page (open for demo)
add_action('rest_api_init', function() {
    register_rest_route('trp/v1', '/settings-save', [
        'methods' => 'POST',
        'callback' => 'trp_handle_settings_save',
        'permission_callback' => '__return_true',
    ]);
});

function trp_handle_settings_save(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $settings = get_option('trp_settings', []);

    // Update coordinates
    $settings['nw_lat'] = floatval($body['nw_lat'] ?? $settings['nw_lat']);
    $settings['nw_lng'] = floatval($body['nw_lng'] ?? $settings['nw_lng']);
    $settings['ne_lat'] = floatval($body['ne_lat'] ?? $settings['ne_lat']);
    $settings['ne_lng'] = floatval($body['ne_lng'] ?? $settings['ne_lng']);
    $settings['sw_lat'] = floatval($body['sw_lat'] ?? $settings['sw_lat']);
    $settings['sw_lng'] = floatval($body['sw_lng'] ?? $settings['sw_lng']);
    $settings['se_lat'] = floatval($body['se_lat'] ?? $settings['se_lat']);
    $settings['se_lng'] = floatval($body['se_lng'] ?? $settings['se_lng']);
    $settings['country_restriction'] = sanitize_text_field($body['country_restriction'] ?? $settings['country_restriction']);

    update_option('trp_settings', $settings);

    return rest_ensure_response(['success' => true]);
}

// Handle proxy Google Maps JavaScript API
function trp_handle_proxy_google_maps(WP_REST_Request $request) {
    $api_key = trp_get_active_api_key();

    if (!$api_key) {
        return new WP_Error('no_api_key', 'Google Maps API key missing', ['status' => 403]);
    }

    $libraries = 'places,geometry';
    $url = "https://maps.googleapis.com/maps/api/js?key=$api_key&libraries=$libraries&loading=async";

    $response = wp_remote_get($url, ['timeout' => 10]);

    if (is_wp_error($response)) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Proxy Google Maps Error: ' . $response->get_error_message()); }
        return new WP_Error('api_error', 'Failed to fetch Google Maps script', ['status' => 500]);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Proxy Google Maps Status: ' . $status_code); }
        return new WP_Error('api_error', 'Google Maps API error', ['status' => $status_code]);
    }

    // Set JavaScript content type
    header('Content-Type: application/javascript');
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Proxying Google Maps API JS, escaping would break it
    echo wp_remote_retrieve_body($response);
    exit; // Ensure no further output
}

// Handle directions request
function trp_handle_directions(WP_REST_Request $request) {
    $api_key = trp_get_active_api_key();

    if (!$api_key) {
        return new WP_Error('no_api_key', 'Google Maps API key missing', ['status' => 403]);
    }

    $body = $request->get_json_params();

    if (!isset($body['origin'], $body['destination'], $body['departureTime'])) {
        return new WP_Error('invalid_input', 'Missing required parameters', ['status' => 400]);
    }

    // Handle origin - can be string or lat/lng object
    if (is_string($body['origin'])) {
        $origin = sanitize_text_field($body['origin']);
    } elseif (is_array($body['origin']) && isset($body['origin']['lat'], $body['origin']['lng'])) {
        $origin = floatval($body['origin']['lat']) . ',' . floatval($body['origin']['lng']);
    } else {
        return new WP_Error('invalid_input', 'Invalid origin format', ['status' => 400]);
    }

    // Handle destination - can be string or lat/lng object
    if (is_string($body['destination'])) {
        $destination = sanitize_text_field($body['destination']);
    } elseif (is_array($body['destination']) && isset($body['destination']['lat'], $body['destination']['lng'])) {
        $destination = floatval($body['destination']['lat']) . ',' . floatval($body['destination']['lng']);
    } else {
        return new WP_Error('invalid_input', 'Invalid destination format', ['status' => 400]);
    }

    $params = [
        'origin' => $origin,
        'destination' => $destination,
        'mode' => 'transit',
        'departure_time' => intval($body['departureTime']),
        'alternatives' => 'true',
        'key' => $api_key,
    ];

    $url = 'https://maps.googleapis.com/maps/api/directions/json?' . http_build_query($params);

    $response = wp_remote_get($url, ['timeout' => 10]);

    if (is_wp_error($response)) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Directions Error: ' . $response->get_error_message()); }
        return new WP_Error('api_error', 'Failed to fetch directions', ['status' => 500]);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Directions Status: ' . $status_code); }
        return new WP_Error('api_error', 'Directions API error', ['status' => $status_code]);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    return rest_ensure_response($data);
}

// Handle autocomplete request
// Uses Google Places API (New) format to match frontend expectations
function trp_handle_autocomplete(WP_REST_Request $request) {
    $api_key = trp_get_active_api_key();

    if (!$api_key) {
        return new WP_Error('no_api_key', 'Google Maps API key missing', ['status' => 403]);
    }

    $body = $request->get_json_params();
    if (!isset($body['input'])) {
        return new WP_Error('invalid_input', 'Missing input parameter', ['status' => 400]);
    }

    // Use Places API (New) - POST with JSON body
    $url = 'https://places.googleapis.com/v1/places:autocomplete';

    // Build request body for Places API (New)
    $request_body = [
        'input' => sanitize_text_field($body['input']),
    ];

    // Add location restriction if provided (rectangle takes priority over circle)
    if (isset($body['locationRestriction']['rectangle'])) {
        $rectangle = $body['locationRestriction']['rectangle'];
        if (isset($rectangle['low']['latitude'], $rectangle['low']['longitude'],
                  $rectangle['high']['latitude'], $rectangle['high']['longitude'])) {
            $request_body['locationRestriction'] = [
                'rectangle' => [
                    'low' => [
                        'latitude' => floatval($rectangle['low']['latitude']),
                        'longitude' => floatval($rectangle['low']['longitude']),
                    ],
                    'high' => [
                        'latitude' => floatval($rectangle['high']['latitude']),
                        'longitude' => floatval($rectangle['high']['longitude']),
                    ],
                ],
            ];
        }
    } elseif (isset($body['locationRestriction']['circle'])) {
        $circle = $body['locationRestriction']['circle'];
        if (isset($circle['center']['lat'], $circle['center']['lng'], $circle['radius'])) {
            $request_body['locationRestriction'] = [
                'circle' => [
                    'center' => [
                        'latitude' => floatval($circle['center']['lat']),
                        'longitude' => floatval($circle['center']['lng']),
                    ],
                    'radius' => floatval($circle['radius']),
                ],
            ];
        }
    }

    $response = wp_remote_post($url, [
        'timeout' => 10,
        'headers' => [
            'Content-Type' => 'application/json',
            'X-Goog-Api-Key' => $api_key,
        ],
        'body' => json_encode($request_body),
    ]);

    if (is_wp_error($response)) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Autocomplete Error: ' . $response->get_error_message()); }
        return new WP_Error('api_error', 'Failed to fetch autocomplete data', ['status' => 500]);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Autocomplete Status: ' . $status_code); }
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Autocomplete Response: ' . wp_remote_retrieve_body($response)); }
        return new WP_Error('api_error', 'Autocomplete API error', ['status' => $status_code]);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    return rest_ensure_response($data);
}

// Handle geocode request
function trp_handle_geocode(WP_REST_Request $request) {
    $api_key = trp_get_active_api_key();

    if (!$api_key) {
        return new WP_Error('no_api_key', 'Google Maps API key missing', ['status' => 403]);
    }

    $address = $request->get_param('address');
    $latlng = $request->get_param('latlng');

    if (!$address && !$latlng) {
        return new WP_Error('invalid_input', 'Missing address or latlng parameter', ['status' => 400]);
    }

    $base_url = 'https://maps.googleapis.com/maps/api/geocode/json';
    $query = $address ? ['address' => sanitize_text_field($address)] : ['latlng' => sanitize_text_field($latlng)];
    $query['key'] = $api_key;

    $response = wp_remote_get(add_query_arg($query, $base_url), [
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Geocode Error: ' . $response->get_error_message()); }
        return new WP_Error('api_error', 'Failed to fetch geocode data', ['status' => 500]);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG enabled
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('TRP Geocode Status: ' . $status_code); }
        return new WP_Error('api_error', 'Geocode API error', ['status' => $status_code]);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    return rest_ensure_response($data);
}

// Handle coverage area toggle
function trp_handle_update_coverage_area(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $show_coverage = isset($body['show_rectangle_coverage_area']) ? (bool) $body['show_rectangle_coverage_area'] : false;

    // Get current settings
    $settings = get_option('trp_settings', []);

    // Update coverage area setting
    $settings['show_rectangle_coverage_area'] = $show_coverage ? 1 : 0;

    // Save settings
    update_option('trp_settings', $settings);

    return rest_ensure_response([
        'success' => true,
        'show_rectangle_coverage_area' => $settings['show_rectangle_coverage_area'],
    ]);
}

// Handle set password request
function trp_handle_set_password(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $password = isset($body['password']) ? $body['password'] : '';

    if (strlen($password) < 8) {
        return new WP_Error('weak_password', 'Password must be at least 8 characters', ['status' => 400]);
    }

    // Check if password already set
    $existing_hash = get_option('trp_admin_password_hash', '');
    if (!empty($existing_hash)) {
        return new WP_Error('password_exists', 'Password already set. Contact system administrator to reset.', ['status' => 403]);
    }

    // Hash and store password
    $hash = password_hash($password, PASSWORD_DEFAULT);
    update_option('trp_admin_password_hash', $hash);

    // Auto-unlock so user can immediately enter API key
    set_transient('trp_api_unlocked_' . get_current_user_id(), true, 300);

    return rest_ensure_response(['success' => true]);
}

// Handle verify password request
function trp_handle_verify_password(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $password = isset($body['password']) ? $body['password'] : '';

    $stored_hash = get_option('trp_admin_password_hash', '');

    if (empty($stored_hash)) {
        return new WP_Error('no_password', 'No password set', ['status' => 400]);
    }

    if (!password_verify($password, $stored_hash)) {
        return new WP_Error('invalid_password', 'Invalid password', ['status' => 401]);
    }

    // Start session and mark as unlocked
    // Use transient instead of session for cross-request state
    set_transient('trp_api_unlocked_' . get_current_user_id(), true, 300);

    return rest_ensure_response(['success' => true]);
}

// Handle lock API key request
function trp_handle_lock_api_key(WP_REST_Request $request) {
    delete_transient('trp_api_unlocked_' . get_current_user_id());

    return rest_ensure_response(['success' => true]);
}

// Handle save API key request
function trp_handle_save_api_key(WP_REST_Request $request) {
    // Check if unlocked
    $is_unlocked = get_transient('trp_api_unlocked_' . get_current_user_id());
    if (!$is_unlocked) {
        return new WP_Error('locked', 'API key is locked. Unlock first.', ['status' => 403]);
    }

    $body = $request->get_json_params();
    $api_key = isset($body['api_key']) ? sanitize_text_field($body['api_key']) : '';

    // Get current settings and update API key
    $settings = get_option('trp_settings', []);
    $settings['google_maps_api_key'] = $api_key;
    update_option('trp_settings', $settings);

    return rest_ensure_response(['success' => true]);
}

// Handle set test API key request
function trp_handle_set_test_key(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $test_key = isset($body['test_key']) ? sanitize_text_field($body['test_key']) : '';
    $duration = isset($body['duration']) ? intval($body['duration']) : 60;

    if (empty($test_key)) {
        return new WP_Error('empty_key', 'Test API key cannot be empty', ['status' => 400]);
    }

    // Validate API key format (basic check)
    if (strlen($test_key) < 20) {
        return new WP_Error('invalid_key', 'Invalid API key format', ['status' => 400]);
    }

    // Limit duration to max 60 minutes
    $duration = min($duration, 60);
    $expiry_time = time() + ($duration * 60);

    // Store test key with expiration
    set_transient('trp_test_api_key', $test_key, $duration * 60);
    set_transient('trp_test_api_key_expiry', $expiry_time, $duration * 60);

    return rest_ensure_response([
        'success' => true,
        'expires_at' => $expiry_time,
        'duration_minutes' => $duration,
    ]);
}

// Handle clear test API key request
function trp_handle_clear_test_key(WP_REST_Request $request) {
    delete_transient('trp_test_api_key');
    delete_transient('trp_test_api_key_expiry');

    return rest_ensure_response(['success' => true]);
}

// Handle AI coordinate lookup
function trp_handle_ai_coordinates(WP_REST_Request $request) {
    $query = sanitize_text_field($request->get_param('query'));

    if (empty($query)) {
        return rest_ensure_response(['success' => false, 'error' => 'No query provided']);
    }

    // Call Vandromeda API (proxies to OpenAI server-side)
    $response = wp_remote_post('https://www.vandromeda.com/api/transit/ai-coordinates.php', [
        'timeout' => 30,
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'body' => wp_json_encode([
            'query' => $query,
            'site_url' => home_url(),
            'plugin_version' => TRP_VERSION,
        ]),
    ]);

    if (is_wp_error($response)) {
        return rest_ensure_response(['success' => false, 'error' => 'AI service temporarily unavailable']);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    // Handle rate limiting
    if ($status_code === 429) {
        return rest_ensure_response([
            'success' => false,
            'error' => isset($body['error']) ? $body['error'] : 'Rate limit exceeded. Please try again later.'
        ]);
    }

    // Handle other errors
    if ($status_code !== 200 || !$body) {
        return rest_ensure_response([
            'success' => false,
            'error' => isset($body['error']) ? $body['error'] : 'AI service error'
        ]);
    }

    // Pass through response from Vandromeda API
    if (!isset($body['success']) || !$body['success']) {
        return rest_ensure_response([
            'success' => false,
            'error' => isset($body['error']) ? $body['error'] : 'Could not determine coordinates'
        ]);
    }

    // Validate coordinates
    if (!isset($body['coordinates'])) {
        return rest_ensure_response(['success' => false, 'error' => 'Invalid response from AI service']);
    }

    $coords = $body['coordinates'];
    $required = ['nw_lat', 'nw_lng', 'ne_lat', 'ne_lng', 'sw_lat', 'sw_lng', 'se_lat', 'se_lng'];
    foreach ($required as $field) {
        if (!isset($coords[$field]) || !is_numeric($coords[$field])) {
            return rest_ensure_response(['success' => false, 'error' => 'Invalid coordinates returned']);
        }
    }

    return rest_ensure_response([
        'success' => true,
        'location' => isset($body['location']) ? $body['location'] : $query,
        'coordinates' => [
            'nw_lat' => floatval($coords['nw_lat']),
            'nw_lng' => floatval($coords['nw_lng']),
            'ne_lat' => floatval($coords['ne_lat']),
            'ne_lng' => floatval($coords['ne_lng']),
            'sw_lat' => floatval($coords['sw_lat']),
            'sw_lng' => floatval($coords['sw_lng']),
            'se_lat' => floatval($coords['se_lat']),
            'se_lng' => floatval($coords['se_lng']),
        ],
    ]);
}

// Get active API key (test key if active, otherwise main key)
function trp_get_active_api_key() {
    // Check for active test key first
    $test_key = get_transient('trp_test_api_key');
    if ($test_key) {
        return $test_key;
    }

    // Fall back to main key
    $settings = get_option('trp_settings', []);
    return isset($settings['google_maps_api_key']) ? sanitize_text_field($settings['google_maps_api_key']) : '';
}

// Shortcode for the route planner
// Usage: [transit_route_planner] or [transit_route_planner layout="mobile"]
function trp_shortcode($atts) {
    global $trp_settings_data;

    $atts = shortcode_atts([
        'layout' => 'default', // 'default' or 'mobile'
    ], $atts, 'transit_route_planner');

    $layout = sanitize_text_field($atts['layout']);

    // Output trpSettings inline with data-no-optimize to bypass LiteSpeed Cache
    $settings_json = wp_json_encode($trp_settings_data);
    $settings_script = '<script type="text/javascript" data-no-optimize="1">var trpSettings = ' . $settings_json . ';</script>';

    // Container style based on layout
    $container_style = $layout === 'mobile'
        ? 'width: 100%;'
        : 'width: 100%; max-width: 1000px; margin: 0 auto;';

    // Standalone admin URL (TransitRoutePlannerAdmin repo)
    $settings_url = site_url('/transit-admin/admin/');

    // Build the output with toggle (always visible for demo purposes)
    $output = $settings_script . '
<style>
.trp-toggle-container { margin-bottom: 15px; text-align: center; }
.trp-toggle-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}
.trp-toggle-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}
.trp-panel { display: block; }
.trp-panel.hidden { display: none; }
.trp-settings-panel {
    background: #f8f9fa;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 20px;
    min-height: 400px;
}
.trp-settings-panel iframe {
    width: 100%;
    height: 600px;
    border: none;
    border-radius: 4px;
    background: white;
}
</style>
<div class="trp-wrapper" style="' . esc_attr($container_style) . '">
    <div class="trp-toggle-container">
        <button type="button" class="trp-toggle-btn" onclick="trpToggleView()">
            <span id="trp-toggle-label">Settings</span>
        </button>
    </div>
    <div id="trp-map-panel" class="trp-panel">
        <div id="trp-root" data-layout="' . esc_attr($layout) . '"></div>
    </div>
    <div id="trp-settings-panel" class="trp-panel hidden">
        <div class="trp-settings-panel">
            <iframe src="' . esc_url($settings_url) . '" title="Transit Route Planner Settings"></iframe>
        </div>
    </div>
</div>
<script type="text/javascript" data-no-optimize="1">
function trpToggleView() {
    var mapPanel = document.getElementById("trp-map-panel");
    var settingsPanel = document.getElementById("trp-settings-panel");
    var label = document.getElementById("trp-toggle-label");

    if (mapPanel.classList.contains("hidden")) {
        // Switching back to map - reload page to pick up new settings
        location.reload();
    } else {
        mapPanel.classList.add("hidden");
        settingsPanel.classList.remove("hidden");
        label.textContent = "Map";
    }
}
</script>';

    return $output;
}
add_shortcode('transit_route_planner', 'trp_shortcode');

// Register plugin settings
function trp_register_settings() {
    add_option('trp_settings', []);
    add_option('trp_admin_password_hash', '');
    register_setting('trp_settings_group', 'trp_settings', 'trp_sanitize_settings');

    add_settings_section(
        'trp_main_section',
        'Transit Route Planner Settings',
        'trp_section_callback',
        'trp-settings'
    );

    // API Key Security section
    add_settings_section(
        'trp_api_key_section',
        'API Key Management',
        'trp_api_key_section_callback',
        'trp-settings'
    );

    add_settings_field(
        'trp_google_maps_api_key',
        'Google Maps API Key',
        'trp_google_maps_api_key_callback',
        'trp-settings',
        'trp_api_key_section'
    );

    add_settings_field(
        'trp_test_api_key',
        'Test API Key (Temporary)',
        'trp_test_api_key_callback',
        'trp-settings',
        'trp_api_key_section'
    );

    add_settings_section(
        'trp_service_area_section',
        'Service Area',
        'trp_service_area_section_callback',
        'trp-settings'
    );

    add_settings_section(
        'trp_map_settings_section',
        'Search Options',
        '__return_null',
        'trp-settings'
    );


    add_settings_field(
        'trp_country_restriction',
        'Limit Searches To',
        'trp_country_restriction_callback',
        'trp-settings',
        'trp_map_settings_section'
    );

}
add_action('admin_init', 'trp_register_settings');

// API Key Section callback
function trp_api_key_section_callback() {
    $password_hash = get_option('trp_admin_password_hash', '');
    if (empty($password_hash)) {
        echo '<div class="notice notice-warning inline" style="margin: 10px 0;">';
        echo '<p><strong>' . esc_html__( 'Security Setup Required:', 'transit-route-planner' ) . '</strong> ' . esc_html__( 'Set an admin password to protect your API key.', 'transit-route-planner' ) . '</p>';
        echo '</div>';
    } else {
        echo '<p>' . esc_html__( 'Your API key is protected. Enter your admin password to make changes.', 'transit-route-planner' ) . '</p>';
    }
}

// Callback for settings section
function trp_section_callback() {
    $settings = get_option('trp_settings', []);
    $api_key = isset($settings['google_maps_api_key']) ? $settings['google_maps_api_key'] : '';
    $test_key = get_transient('trp_test_api_key');
    $test_key_expiry = get_transient('trp_test_api_key_expiry');

    // Show test key warning if active
    if ($test_key && $test_key_expiry) {
        $remaining = $test_key_expiry - time();
        if ($remaining > 0) {
            $remaining_minutes = ceil($remaining / 60);
            echo '<div class="notice notice-info inline" style="margin: 10px 0 20px; border-left-color: #00a0d2;"><p>';
            /* translators: %d: number of minutes remaining */
            echo '<strong>' . esc_html__( 'Test API Key Active:', 'transit-route-planner' ) . '</strong> ' . esc_html( sprintf( __( 'Using temporary test key for %d more minutes.', 'transit-route-planner' ), $remaining_minutes ) );
            echo '</p></div>';
        }
    }

    // Show setup status
    if (empty($api_key)) {
        echo '<div class="notice notice-warning inline" style="margin: 10px 0 20px;"><p>';
        echo '<strong>' . esc_html__( 'Setup Required:', 'transit-route-planner' ) . '</strong> ' . esc_html__( 'Enter your Google Maps API key below to enable the plugin.', 'transit-route-planner' );
        echo '</p></div>';
    } else {
        echo '<div class="notice notice-success inline" style="margin: 10px 0 20px;"><p>';
        echo '<strong>' . esc_html__( 'Plugin Ready:', 'transit-route-planner' ) . '</strong> ' . esc_html__( 'Use the shortcode', 'transit-route-planner' ) . ' <code>[transit_route_planner]</code> ' . esc_html__( 'on any page.', 'transit-route-planner' );
        echo '</p></div>';
    }

    echo '<p>' . esc_html__( 'Configure settings for the Transit Route Planner plugin.', 'transit-route-planner' ) . ' ';
    echo '<a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">' . esc_html__( 'Get a Google Maps API key', 'transit-route-planner' ) . '</a>';
    echo '</p>';
}

// Service Area Section callback
function trp_service_area_section_callback() {
    $settings = get_option('trp_settings', []);
    $nw_lat = isset($settings['nw_lat']) ? $settings['nw_lat'] : '46.7667';
    $nw_lng = isset($settings['nw_lng']) ? $settings['nw_lng'] : '-123.2167';
    $ne_lat = isset($settings['ne_lat']) ? $settings['ne_lat'] : '46.7667';
    $ne_lng = isset($settings['ne_lng']) ? $settings['ne_lng'] : '-121.3167';
    $sw_lat = isset($settings['sw_lat']) ? $settings['sw_lat'] : '46.3333';
    $sw_lng = isset($settings['sw_lng']) ? $settings['sw_lng'] : '-123.2167';
    $se_lat = isset($settings['se_lat']) ? $settings['se_lat'] : '46.3333';
    $se_lng = isset($settings['se_lng']) ? $settings['se_lng'] : '-121.3167';
    ?>
    <style>
        .trp-ai-chatbox { border: 1px solid #c3c4c7; border-radius: 8px; overflow: hidden; background: #f6f7f7; margin-bottom: 20px; max-width: 600px; }
        .trp-ai-header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 10px 14px; font-weight: 500; font-size: 13px; display: flex; align-items: center; gap: 8px; }
        .trp-ai-messages { padding: 14px; max-height: 180px; overflow-y: auto; background: white; }
        .trp-ai-msg { padding: 10px 14px; border-radius: 12px; margin-bottom: 10px; font-size: 13px; line-height: 1.5; max-width: 85%; }
        .trp-ai-msg:last-child { margin-bottom: 0; }
        .trp-ai-assistant { background: #f0f0f1; color: #1d2327; border-bottom-left-radius: 4px; }
        .trp-ai-user { background: #2271b1; color: white; margin-left: auto; border-bottom-right-radius: 4px; }
        .trp-ai-error { background: #fcf0f1; color: #d63638; border: 1px solid #d63638; }
        .trp-ai-success { background: #edfaef; color: #00a32a; border: 1px solid #00a32a; }
        .trp-ai-locations { padding: 8px 14px; background: #edfaef; border-top: 1px solid #c3c4c7; display: none; }
        .trp-ai-locations.has-locations { display: block; }
        .trp-ai-locations-label { font-size: 11px; font-weight: 600; color: #1e4620; text-transform: uppercase; margin-bottom: 6px; }
        .trp-ai-tags { display: flex; flex-wrap: wrap; gap: 6px; }
        .trp-ai-tag { display: inline-flex; align-items: center; gap: 6px; background: white; border: 1px solid #68de7c; color: #1e4620; padding: 4px 8px 4px 10px; border-radius: 16px; font-size: 12px; }
        .trp-ai-tag button { background: none; border: none; color: #d63638; cursor: pointer; padding: 0; width: 16px; height: 16px; }
        .trp-ai-input { display: flex; gap: 8px; padding: 10px 14px; background: #f0f0f1; border-top: 1px solid #c3c4c7; }
        .trp-ai-input input { flex: 1; border-radius: 20px; padding: 8px 16px; border: 1px solid #c3c4c7; }
        .trp-ai-input button { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; }
        .trp-ai-input button:disabled { opacity: 0.5; }
        .trp-ai-input .trp-ai-add-btn { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); }
        .trp-ai-typing { display: flex; gap: 4px; padding: 10px 14px; }
        .trp-ai-typing span { width: 8px; height: 8px; background: #8c8f94; border-radius: 50%; animation: trpBounce 1.4s infinite ease-in-out; }
        .trp-ai-typing span:nth-child(1) { animation-delay: -0.32s; }
        .trp-ai-typing span:nth-child(2) { animation-delay: -0.16s; }
        @keyframes trpBounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
    </style>

    <!-- AI Coordinate Lookup Chatbox -->
    <div class="trp-ai-chatbox">
        <div class="trp-ai-header">
            <span class="dashicons dashicons-format-chat"></span>
            <span>AI Coordinate Lookup</span>
        </div>
        <div class="trp-ai-messages" id="trp-ai-messages">
            <div class="trp-ai-msg trp-ai-assistant">
                Enter a location and press the green arrow. Use the blue + to add multiple locations and combine them into one bounding box.
            </div>
        </div>
        <div class="trp-ai-locations" id="trp-ai-locations">
            <div class="trp-ai-locations-label">Locations to combine:</div>
            <div class="trp-ai-tags" id="trp-ai-tags"></div>
        </div>
        <div class="trp-ai-input">
            <input type="text" id="trp-ai-query" placeholder="Enter a location (e.g., Lewis County, WA)" onkeypress="if(event.key==='Enter')document.getElementById('trp-ai-send').click()">
            <button type="button" onclick="trpAiAddLocation()" id="trp-ai-add" class="trp-ai-add-btn" title="Add location to combine">+</button>
            <button type="button" onclick="trpAiLookup()" id="trp-ai-send" title="Look up coordinates">&#10148;</button>
        </div>
    </div>

    <p class="description" style="margin-bottom: 15px;">Define the transit service coverage area. Drag the rectangle corners on the map or edit coordinates directly.</p>

    <!-- Interactive Map -->
    <div id="trp-bounds-map" style="width: 100%; height: 350px; border-radius: 8px; margin-bottom: 20px; background: #e2e8f0;"></div>

    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; max-width: 600px;">
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
            <strong style="display: block; margin-bottom: 10px;">Northwest</strong>
            <label style="display: block; margin-bottom: 5px;">Lat: <input type="number" step="any" name="trp_settings[nw_lat]" id="trp_nw_lat" value="<?php echo esc_attr($nw_lat); ?>" style="width: 140px;" /></label>
            <label>Lng: <input type="number" step="any" name="trp_settings[nw_lng]" id="trp_nw_lng" value="<?php echo esc_attr($nw_lng); ?>" style="width: 140px;" /></label>
        </div>
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
            <strong style="display: block; margin-bottom: 10px;">Northeast</strong>
            <label style="display: block; margin-bottom: 5px;">Lat: <input type="number" step="any" name="trp_settings[ne_lat]" id="trp_ne_lat" value="<?php echo esc_attr($ne_lat); ?>" style="width: 140px;" /></label>
            <label>Lng: <input type="number" step="any" name="trp_settings[ne_lng]" id="trp_ne_lng" value="<?php echo esc_attr($ne_lng); ?>" style="width: 140px;" /></label>
        </div>
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
            <strong style="display: block; margin-bottom: 10px;">Southwest</strong>
            <label style="display: block; margin-bottom: 5px;">Lat: <input type="number" step="any" name="trp_settings[sw_lat]" id="trp_sw_lat" value="<?php echo esc_attr($sw_lat); ?>" style="width: 140px;" /></label>
            <label>Lng: <input type="number" step="any" name="trp_settings[sw_lng]" id="trp_sw_lng" value="<?php echo esc_attr($sw_lng); ?>" style="width: 140px;" /></label>
        </div>
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
            <strong style="display: block; margin-bottom: 10px;">Southeast</strong>
            <label style="display: block; margin-bottom: 5px;">Lat: <input type="number" step="any" name="trp_settings[se_lat]" id="trp_se_lat" value="<?php echo esc_attr($se_lat); ?>" style="width: 140px;" /></label>
            <label>Lng: <input type="number" step="any" name="trp_settings[se_lng]" id="trp_se_lng" value="<?php echo esc_attr($se_lng); ?>" style="width: 140px;" /></label>
        </div>
    </div>

    <!-- Coverage Area Display Toggle -->
    <div style="margin-top: 20px; padding: 15px; background: #f0f6fc; border: 1px solid #c3c4c7; border-radius: 8px; max-width: 600px;">
        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
            <input type="checkbox" name="trp_settings[show_rectangle_coverage_area]" value="1" <?php echo !empty($settings['show_rectangle_coverage_area']) ? 'checked' : ''; ?> style="width: 18px; height: 18px;" />
            <span style="font-weight: 500;">Show coverage area rectangle on the map</span>
        </label>
        <p class="description" style="margin: 8px 0 0 28px;">When enabled, displays a shaded rectangle on the frontend map showing the transit service area boundaries.</p>
    </div>
    <?php
}

// Google Maps API Key callback with password protection
function trp_google_maps_api_key_callback() {
    $settings = get_option('trp_settings', []);
    $api_key = isset($settings['google_maps_api_key']) ? $settings['google_maps_api_key'] : '';
    $password_hash = get_option('trp_admin_password_hash', '');
    $is_unlocked = get_transient('trp_api_unlocked_' . get_current_user_id());

    // If no password set, show setup form
    if (empty($password_hash)) {
        ?>
        <div id="trp-password-setup" style="background: #fff; border: 1px solid #c3c4c7; padding: 15px; max-width: 400px;">
            <h4 style="margin-top: 0;">Set Admin Password</h4>
            <p class="description">Create a password to protect your API key from unauthorized changes.</p>
            <input type="password" id="trp-new-password" class="regular-text" placeholder="Enter new password" style="margin-bottom: 10px; display: block;" />
            <input type="password" id="trp-confirm-password" class="regular-text" placeholder="Confirm password" style="margin-bottom: 10px; display: block;" />
            <button type="button" class="button button-primary" onclick="trpSetPassword()">Set Password</button>
            <span id="trp-password-status" style="margin-left: 10px;"></span>
        </div>
        <div id="trp-api-key-field" style="display: none;">
            <input type="password" name="trp_settings[google_maps_api_key]" value="<?php echo esc_attr($api_key); ?>" class="regular-text" autocomplete="off" />
        </div>
        <?php
    } elseif ($is_unlocked) {
        // Password verified - show editable field
        ?>
        <div id="trp-api-key-unlocked">
            <input type="password" name="trp_settings[google_maps_api_key]" id="trp-api-key-input" value="<?php echo esc_attr($api_key); ?>" class="regular-text" autocomplete="off" />
            <button type="button" class="button" onclick="trpToggleKeyVisibility()" style="margin-left: 5px;">Show</button>
            <button type="button" class="button" onclick="trpLockApiKey()" style="margin-left: 5px;">Lock</button>
            <span style="color: green; margin-left: 10px;">&#10003; Unlocked</span>
        </div>
        <?php
    } else {
        // Password required - show masked key and unlock form (only show last 4 chars for security)
        $masked_key = !empty($api_key) ? '••••••••••••••••' . substr($api_key, -4) : '(not set)';
        ?>
        <div id="trp-api-key-locked">
            <code style="padding: 5px 10px; background: #f0f0f0;"><?php echo esc_html($masked_key); ?></code>
            <span style="color: #666; margin-left: 10px;">&#128274; Locked</span>
        </div>
        <div id="trp-unlock-form" style="margin-top: 10px;">
            <input type="password" id="trp-admin-password" class="regular-text" placeholder="Enter admin password" style="width: 200px;" />
            <button type="button" class="button" onclick="trpUnlockApiKey()">Unlock</button>
            <span id="trp-unlock-status" style="margin-left: 10px;"></span>
        </div>
        <input type="hidden" name="trp_settings[google_maps_api_key]" value="<?php echo esc_attr($api_key); ?>" />
        <?php
    }
    ?>
    <p class='description' style="margin-top: 10px;">Required APIs: <strong>Maps JavaScript</strong>, <strong>Places</strong>, <strong>Directions</strong>, <strong>Geocoding</strong></p>
    <p class='description' style="margin-top: 5px; padding: 8px; background: #fff8e5; border-left: 3px solid #ffb900;">
        <strong>Security tip:</strong> In <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a>, restrict this API key to your domain(s) under "Application restrictions" → "HTTP referrers". This prevents unauthorized use even if the key is exposed.
    </p>
    <?php
}

// Test API Key callback
function trp_test_api_key_callback() {
    $test_key = get_transient('trp_test_api_key');
    $test_key_expiry = get_transient('trp_test_api_key_expiry');
    $remaining_time = '';

    if ($test_key && $test_key_expiry) {
        $remaining = $test_key_expiry - time();
        if ($remaining > 0) {
            $remaining_time = sprintf('%d minutes remaining', ceil($remaining / 60));
        }
    }
    ?>
    <div id="trp-test-key-section">
        <?php if ($test_key && $remaining_time): ?>
            <div style="margin-bottom: 10px;">
                <code style="padding: 5px 10px; background: #e7f5e7;"><?php echo esc_html('••••••••••••••••' . substr($test_key, -4)); ?></code>
                <span style="color: green; margin-left: 10px;">Active - <?php echo esc_html($remaining_time); ?></span>
                <button type="button" class="button" onclick="trpClearTestKey()" style="margin-left: 10px;">Clear</button>
            </div>
        <?php endif; ?>
        <input type="text" id="trp-test-api-key" class="regular-text" placeholder="Enter test API key" value="" autocomplete="off" />
        <select id="trp-test-duration">
            <option value="15">15 minutes</option>
            <option value="30">30 minutes</option>
            <option value="60" selected>1 hour</option>
        </select>
        <button type="button" class="button" onclick="trpSetTestKey()">Activate Test Key</button>
        <span id="trp-test-key-status" style="margin-left: 10px;"></span>
    </div>
    <p class='description'>Use a temporary API key for testing. Maximum duration: 1 hour. This key will be used instead of the main key while active.</p>
    <?php
}

// OpenAI API Key callback
// Center Coordinates callback
function trp_center_callback() {
    $settings = get_option('trp_settings', []);
    $center_lat = isset($settings['center_lat']) ? $settings['center_lat'] : '46.6621';
    $center_lng = isset($settings['center_lng']) ? $settings['center_lng'] : '-122.964';
    ?>
    <label>Latitude: <input type="number" step="any" name="trp_settings[center_lat]" value="<?php echo esc_attr($center_lat); ?>" /></label><br>
    <label>Longitude: <input type="number" step="any" name="trp_settings[center_lng]" value="<?php echo esc_attr($center_lng); ?>" /></label>
    <?php
}

// Autocomplete Radius callback
function trp_radius_callback() {
    $settings = get_option('trp_settings', []);
    $radius = isset($settings['radius']) ? $settings['radius'] : '50000.0';
    ?>
    <input type="number" step="any" name="trp_settings[radius]" value="<?php echo esc_attr($radius); ?>" />
    <?php
}

// Country Restriction callback
function trp_country_restriction_callback() {
    $settings = get_option('trp_settings', []);
    $country = isset($settings['country_restriction']) ? $settings['country_restriction'] : 'us';
    ?>
    <input type="text" name="trp_settings[country_restriction]" value="<?php echo esc_attr($country); ?>" style="width: 80px;" />
    <p class="description">Restrict location suggestions to a country code (e.g., 'us' for United States)</p>
    <?php
}

// Default Travel Mode callback
function trp_travel_mode_callback() {
    $settings = get_option('trp_settings', []);
    $travel_mode = isset($settings['travel_mode']) ? $settings['travel_mode'] : 'TRANSIT';
    $options = ['TRANSIT', 'DRIVING', 'WALKING', 'BICYCLING'];
    ?>
    <select name="trp_settings[travel_mode]">
    <?php foreach ($options as $option) : ?>
        <option value="<?php echo esc_attr($option); ?>" <?php selected($travel_mode, $option); ?>><?php echo esc_html($option); ?></option>
    <?php endforeach; ?>
    </select>
    <?php
}

// Map Zoom Level callback
function trp_zoom_level_callback() {
    $settings = get_option('trp_settings', []);
    $zoom_level = isset($settings['zoom_level']) ? $settings['zoom_level'] : '11';
    ?>
    <input type="number" name="trp_settings[zoom_level]" value="<?php echo esc_attr($zoom_level); ?>" min="1" max="20" />
    <?php
}

// Sanitize settings
function trp_sanitize_settings($input) {
    $sanitized = [];

    // API Key
    $sanitized['google_maps_api_key'] = sanitize_text_field($input['google_maps_api_key'] ?? '');

    // Search Options
    $sanitized['country_restriction'] = sanitize_text_field($input['country_restriction'] ?? 'us');

    // Service Area - Region Corners
    $sanitized['nw_lat'] = floatval($input['nw_lat'] ?? 46.7667);
    $sanitized['nw_lng'] = floatval($input['nw_lng'] ?? -123.2167);
    $sanitized['ne_lat'] = floatval($input['ne_lat'] ?? 46.7667);
    $sanitized['ne_lng'] = floatval($input['ne_lng'] ?? -121.3167);
    $sanitized['sw_lat'] = floatval($input['sw_lat'] ?? 46.3333);
    $sanitized['sw_lng'] = floatval($input['sw_lng'] ?? -123.2167);
    $sanitized['se_lat'] = floatval($input['se_lat'] ?? 46.3333);
    $sanitized['se_lng'] = floatval($input['se_lng'] ?? -121.3167);

    // Legacy settings - preserve for backwards compatibility
    $sanitized['center_lat'] = floatval($input['center_lat'] ?? 46.6621);
    $sanitized['center_lng'] = floatval($input['center_lng'] ?? -122.964);
    $sanitized['radius'] = floatval($input['radius'] ?? 50000.0);
    $sanitized['travel_mode'] = 'TRANSIT';
    $sanitized['zoom_level'] = 11;

    // Coverage area display toggles - store as integers (1/0)
    // Preserve existing value if not in form submission
    $existing = get_option('trp_settings', []);
    $sanitized['show_rectangle_coverage_area'] = isset($input['show_rectangle_coverage_area'])
        ? (!empty($input['show_rectangle_coverage_area']) ? 1 : 0)
        : (!empty($existing['show_rectangle_coverage_area']) ? 1 : 0);

    return $sanitized;
}

// Purge LiteSpeed cache after settings are saved (not during sanitization)
function trp_purge_cache_after_save($old_value, $new_value) {
    if (class_exists('LiteSpeed_Cache_API')) {
        LiteSpeed_Cache_API::purge_all();
    } elseif (function_exists('litespeed_purge_all')) {
        litespeed_purge_all();
    }
}
add_action('update_option_trp_settings', 'trp_purge_cache_after_save', 10, 2);

// Add top-level menu to the admin sidebar
function trp_add_admin_menu() {
    add_menu_page(
        'Transit Route Planner Settings',
        'Transit Route Planner',
        'manage_options',
        'trp-settings',
        'trp_settings_page',
        'dashicons-admin-site-alt3',
        80
    );

    // Add License submenu
    add_submenu_page(
        'trp-settings',
        'License',
        'License',
        'manage_options',
        'trp-license',
        'trp_license_page'
    );

    // Add Upgrade to Pro submenu (only show for free version)
    $license_status = get_option('trp_license_status', []);
    if (empty($license_status['is_pro'])) {
        add_submenu_page(
            'trp-settings',
            'Upgrade to Pro',
            '<span style="color: #00a32a;">Upgrade to Pro</span>',
            'manage_options',
            'trp-upgrade',
            'trp_upgrade_page'
        );
    }
}
add_action('admin_menu', 'trp_add_admin_menu');

// Enqueue admin scripts
function trp_enqueue_admin_scripts($hook) {
    if ($hook !== 'toplevel_page_trp-settings') {
        return;
    }

    // Get the API key to load Google Maps for the interactive map
    $settings = get_option('trp_settings', []);
    $api_key = isset($settings['google_maps_api_key']) ? $settings['google_maps_api_key'] : '';

    // Load Google Maps API if we have an API key
    if (!empty($api_key)) {
        wp_enqueue_script(
            'google-maps-api',
            'https://maps.googleapis.com/maps/api/js?key=' . esc_attr($api_key) . '&libraries=places&loading=async',
            array(),
            '3.0',
            true
        );
    }

    trp_enqueue_admin_js();
}
add_action('admin_enqueue_scripts', 'trp_enqueue_admin_scripts');

// Get admin JavaScript
function trp_enqueue_admin_js() {
    wp_enqueue_script(
        'trp-admin-js',
        plugins_url('admin/admin.js', __FILE__),
        array(),
        TRP_VERSION,
        true
    );
    wp_localize_script('trp-admin-js', 'trpAdminVars', array(
        'restUrl' => esc_url(rest_url('trp/v1/admin/')),
        'nonce'   => wp_create_nonce('wp_rest'),
    ));
}

function trp_get_admin_js() {
    // Legacy function - now using enqueued script
    return '/* Admin JS now loaded via wp_enqueue_script */';
}


// Render the settings page
function trp_settings_page() {
    $settings = get_option('trp_settings', []);
    $api_key = isset($settings['google_maps_api_key']) ? $settings['google_maps_api_key'] : '';
    ?>
    <div class="wrap">
        <h1>Transit Route Planner <span style="font-size: 12px; font-weight: normal; color: #666; margin-left: 10px;">v<?php echo esc_html(TRP_VERSION); ?></span></h1>

        <?php if (empty($api_key)): ?>
        <div class="card" style="max-width: 800px; margin: 20px 0;">
            <h2>Quick Start Guide</h2>
            <ol style="line-height: 1.8;">
                <li><strong>Get API Key:</strong> <a href="https://console.cloud.google.com/google/maps-apis/credentials" target="_blank">Google Cloud Console</a></li>
                <li><strong>Enable APIs:</strong> Maps JavaScript, Places, Directions, Geocoding</li>
                <li><strong>Enter Key:</strong> Paste your API key in the form below</li>
                <li><strong>Add Shortcode:</strong> Use <code>[transit_route_planner]</code> on any page</li>
            </ol>
        </div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php
            settings_fields('trp_settings_group');
            do_settings_sections('trp-settings');
            submit_button();
            ?>
        </form>

        <?php if (!empty($api_key)): ?>
        <div class="card" style="max-width: 800px; margin: 20px 0;">
            <h2>Usage</h2>
            <p>Add this shortcode to any page or post:</p>
            <p><code style="font-size: 14px; padding: 8px 12px; background: #f0f0f0; display: inline-block;">[transit_route_planner]</code></p>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// License page
function trp_license_page() {
    // Handle form submissions
    if (isset($_POST['trp_license_action']) && check_admin_referer('trp_license_nonce')) {
        $action = sanitize_text_field(wp_unslash($_POST['trp_license_action']));

        if ($action === 'activate' && !empty($_POST['trp_license_key'])) {
            $license_key = sanitize_text_field(wp_unslash($_POST['trp_license_key']));
            $result = trp_activate_license($license_key);

            if ($result['success']) {
                echo '<div class="notice notice-success"><p>' . esc_html__( 'License activated successfully!', 'transit-route-planner' ) . '</p></div>';
            } else {
                /* translators: %s: error message */
                echo '<div class="notice notice-error"><p>' . esc_html( sprintf( __( 'Activation failed: %s', 'transit-route-planner' ), $result['error'] ) ) . '</p></div>';
            }
        } elseif ($action === 'deactivate') {
            $result = trp_deactivate_license();

            if ($result['success']) {
                echo '<div class="notice notice-success"><p>' . esc_html__( 'License deactivated.', 'transit-route-planner' ) . '</p></div>';
            } else {
                /* translators: %s: error message */
                echo '<div class="notice notice-error"><p>' . esc_html( sprintf( __( 'Deactivation failed: %s', 'transit-route-planner' ), $result['error'] ) ) . '</p></div>';
            }
        }
    }

    $license_status = get_option('trp_license_status', []);
    $is_pro = !empty($license_status['is_pro']);
    $license_key = isset($license_status['license_key']) ? $license_status['license_key'] : '';
    $expires_at = isset($license_status['expires_at']) ? $license_status['expires_at'] : '';
    $tier = isset($license_status['tier']) ? $license_status['tier'] : 'free';

    $tier_names = [
        'free' => __( 'Free', 'transit-route-planner' ),
        'pro_1' => __( 'Pro (1 Site)', 'transit-route-planner' ),
        'pro_5' => __( 'Pro (5 Sites)', 'transit-route-planner' ),
        'agency' => __( 'Agency (Unlimited)', 'transit-route-planner' ),
    ];
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Transit Route Planner License', 'transit-route-planner' ); ?></h1>

        <?php if ($is_pro): ?>
        <div class="card" style="max-width: 600px; margin: 20px 0; border-left: 4px solid #00a32a;">
            <h2 style="color: #00a32a; margin-top: 0;"><?php esc_html_e( 'Pro License Active', 'transit-route-planner' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'License Key', 'transit-route-planner' ); ?></th>
                    <td><code><?php echo esc_html(trp_mask_license_key($license_key)); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'License Tier', 'transit-route-planner' ); ?></th>
                    <td><?php echo esc_html($tier_names[$tier] ?? $tier); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Expires', 'transit-route-planner' ); ?></th>
                    <td><?php echo esc_html(gmdate('F j, Y', strtotime($expires_at))); ?></td>
                </tr>
            </table>

            <form method="post" style="margin-top: 20px;">
                <?php wp_nonce_field('trp_license_nonce'); ?>
                <input type="hidden" name="trp_license_action" value="deactivate">
                <p class="description"><?php esc_html_e( 'Deactivating will remove this domain from your license, freeing it for use elsewhere.', 'transit-route-planner' ); ?></p>
                <button type="submit" class="button" onclick="return confirm('<?php echo esc_js( __( 'Are you sure you want to deactivate the license on this site?', 'transit-route-planner' ) ); ?>');">
                    <?php esc_html_e( 'Deactivate License', 'transit-route-planner' ); ?>
                </button>
            </form>
        </div>

        <div class="card" style="max-width: 600px; margin: 20px 0;">
            <h3><?php esc_html_e( 'Pro Features Unlocked', 'transit-route-planner' ); ?></h3>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><?php esc_html_e( 'Unlimited route calculations', 'transit-route-planner' ); ?></li>
                <li><?php esc_html_e( 'Saved routes', 'transit-route-planner' ); ?></li>
                <li><?php esc_html_e( 'Multiple maps per page', 'transit-route-planner' ); ?></li>
                <li><?php esc_html_e( 'Custom styling options', 'transit-route-planner' ); ?></li>
                <li><?php esc_html_e( 'Priority support', 'transit-route-planner' ); ?></li>
                <li><?php esc_html_e( 'Remove branding', 'transit-route-planner' ); ?></li>
            </ul>
        </div>

        <?php else: ?>
        <div class="card" style="max-width: 600px; margin: 20px 0;">
            <h2><?php esc_html_e( 'Activate Pro License', 'transit-route-planner' ); ?></h2>
            <p><?php esc_html_e( 'Enter your license key to unlock Pro features.', 'transit-route-planner' ); ?></p>

            <form method="post">
                <?php wp_nonce_field('trp_license_nonce'); ?>
                <input type="hidden" name="trp_license_action" value="activate">

                <table class="form-table">
                    <tr>
                        <th><label for="trp_license_key"><?php esc_html_e( 'License Key', 'transit-route-planner' ); ?></label></th>
                        <td>
                            <input type="text"
                                   name="trp_license_key"
                                   id="trp_license_key"
                                   class="regular-text"
                                   placeholder="XXXX-XXXX-XXXX-XXXX"
                                   pattern="[A-Fa-f0-9]{8}-[A-Fa-f0-9]{8}-[A-Fa-f0-9]{8}-[A-Fa-f0-9]{8}"
                                   required>
                            <p class="description"><?php esc_html_e( 'Format: XXXX-XXXX-XXXX-XXXX', 'transit-route-planner' ); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary"><?php esc_html_e( 'Activate License', 'transit-route-planner' ); ?></button>
                </p>
            </form>
        </div>

        <div class="card" style="max-width: 600px; margin: 20px 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h2 style="color: white; margin-top: 0;"><?php esc_html_e( "Don't have a license?", 'transit-route-planner' ); ?></h2>
            <p><?php esc_html_e( 'Upgrade to Pro for unlimited routes, custom styling, and more.', 'transit-route-planner' ); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=trp-upgrade')); ?>"
               class="button button-secondary"
               style="background: white; color: #667eea; border: none;">
                <?php esc_html_e( 'View Pricing', 'transit-route-planner' ); ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// Upgrade to Pro page
function trp_upgrade_page() {
    // Fetch pricing from API (cached)
    $pricing = trp_get_pricing();
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Upgrade to Transit Route Planner Pro', 'transit-route-planner' ); ?></h1>

        <div style="max-width: 1000px; margin: 20px 0;">
            <p style="font-size: 16px;">
                <?php esc_html_e( 'Unlock the full potential of Transit Route Planner with a Pro license. Get unlimited route calculations, custom styling, and premium support.', 'transit-route-planner' ); ?>
            </p>

            <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-top: 30px;">
                <?php foreach ($pricing['products'] as $product): ?>
                <div class="card" style="flex: 1; min-width: 280px; max-width: 320px; position: relative;
                    <?php echo esc_attr($product['popular'] ? 'border: 2px solid #667eea;' : ''); ?>">

                    <?php if ($product['popular']): ?>
                    <div style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%);
                                background: #667eea; color: white; padding: 4px 12px; border-radius: 12px;
                                font-size: 12px; font-weight: bold;">
                        <?php esc_html_e( 'MOST POPULAR', 'transit-route-planner' ); ?>
                    </div>
                    <?php endif; ?>

                    <h2 style="margin-top: 10px;"><?php echo esc_html($product['name']); ?></h2>

                    <div style="font-size: 36px; font-weight: bold; color: #667eea;">
                        $<?php echo esc_html($product['price']); ?>
                        <span style="font-size: 16px; color: #666; font-weight: normal;"><?php esc_html_e( '/year', 'transit-route-planner' ); ?></span>
                    </div>

                    <p style="color: #666; margin: 10px 0;">
                        <?php
                        if ($product['domains'] === -1) {
                            esc_html_e( 'Unlimited websites', 'transit-route-planner' );
                        } elseif ($product['domains'] === 1) {
                            esc_html_e( '1 website', 'transit-route-planner' );
                        } else {
                            /* translators: %d: number of websites */
                            echo esc_html( sprintf( __( '%d websites', 'transit-route-planner' ), $product['domains'] ) );
                        }
                        ?>
                    </p>

                    <ul style="list-style: none; padding: 0; margin: 20px 0;">
                        <?php foreach ($product['features'] as $feature): ?>
                        <li style="padding: 8px 0; border-bottom: 1px solid #eee;">
                            <span style="color: #00a32a; margin-right: 8px;">&#10003;</span>
                            <?php echo esc_html($feature); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>

                    <a href="<?php echo esc_url(trp_get_checkout_url($product['tier'])); ?>"
                       class="button button-primary button-large"
                       style="width: 100%; text-align: center;
                              <?php echo esc_attr($product['popular'] ? 'background: #667eea; border-color: #667eea;' : ''); ?>"
                       target="_blank">
                        <?php esc_html_e( 'Buy Now', 'transit-route-planner' ); ?>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="card" style="max-width: 100%; margin-top: 30px;">
                <h3><?php esc_html_e( 'Frequently Asked Questions', 'transit-route-planner' ); ?></h3>

                <h4><?php esc_html_e( 'How does licensing work?', 'transit-route-planner' ); ?></h4>
                <p><?php esc_html_e( "Each license is valid for one year and can be used on a specific number of domains depending on your tier. When you purchase, you'll receive a license key via email along with a download link for the Pro plugin.", 'transit-route-planner' ); ?></p>

                <h4><?php esc_html_e( 'What happens when my license expires?', 'transit-route-planner' ); ?></h4>
                <p><?php esc_html_e( "The plugin will continue to work, but you won't receive updates or support. Renew your license to continue receiving updates and access to new features.", 'transit-route-planner' ); ?></p>

                <h4><?php esc_html_e( 'Can I upgrade my license later?', 'transit-route-planner' ); ?></h4>
                <p><?php esc_html_e( "Yes! Contact us at support@vandromeda.com and we'll help you upgrade to a higher tier.", 'transit-route-planner' ); ?></p>

                <h4><?php esc_html_e( 'Is there a money-back guarantee?', 'transit-route-planner' ); ?></h4>
                <p><?php esc_html_e( "Yes, we offer a 30-day money-back guarantee. If you're not satisfied, contact us for a full refund.", 'transit-route-planner' ); ?></p>
            </div>
        </div>
    </div>
    <?php
}

// Helper: Mask license key for display
function trp_mask_license_key($key) {
    if (strlen($key) < 8) return $key;
    return substr($key, 0, 4) . '-****-****-' . substr($key, -4);
}

// Helper: Get pricing from Vandromeda API (cached)
function trp_get_pricing() {
    $cached = get_transient('trp_pricing');
    if ($cached !== false) {
        return $cached;
    }

    $response = wp_remote_get('https://www.vandromeda.com/api/payments/transit-pricing.php', [
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        // Return default pricing on error
        return trp_get_default_pricing();
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (empty($body['success'])) {
        return trp_get_default_pricing();
    }

    // Cache for 1 hour
    set_transient('trp_pricing', $body, HOUR_IN_SECONDS);

    return $body;
}

// Default pricing fallback
function trp_get_default_pricing() {
    return [
        'success' => true,
        'products' => [
            [
                'tier' => 'pro_1',
                'name' => 'Pro (1 Site)',
                'price' => 49,
                'domains' => 1,
                'features' => ['Unlimited routes', 'Custom styling', 'Priority support'],
                'popular' => false,
            ],
            [
                'tier' => 'pro_5',
                'name' => 'Pro (5 Sites)',
                'price' => 149,
                'domains' => 5,
                'features' => ['Everything in Pro', '5 websites', 'Priority support'],
                'popular' => true,
            ],
            [
                'tier' => 'agency',
                'name' => 'Agency',
                'price' => 299,
                'domains' => -1,
                'features' => ['Everything in Pro', 'Unlimited sites', 'Premium support'],
                'popular' => false,
            ],
        ],
    ];
}

// Helper: Get checkout URL
function trp_get_checkout_url($tier) {
    $site_url = get_site_url();
    $admin_email = get_option('admin_email');

    return add_query_arg([
        'tier' => $tier,
        'email' => urlencode($admin_email),
        'site' => urlencode($site_url),
    ], 'https://www.vandromeda.com/checkout/transit-route-planner');
}

// Activate license via Vandromeda API
function trp_activate_license($license_key) {
    $domain = wp_parse_url(get_site_url(), PHP_URL_HOST);

    $response = wp_remote_post('https://www.vandromeda.com/api/license/activate.php', [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode([
            'license_key' => $license_key,
            'domain' => $domain,
        ]),
    ]);

    if (is_wp_error($response)) {
        return ['success' => false, 'error' => $response->get_error_message()];
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!empty($body['success'])) {
        // Store license status
        update_option('trp_license_status', [
            'is_pro' => true,
            'license_key' => $license_key,
            'tier' => $body['license_info']['tier'] ?? 'pro_1',
            'expires_at' => $body['license_info']['expires_at'] ?? '',
            'domains_used' => count($body['license_info']['domains'] ?? []),
            'max_domains' => $body['license_info']['max_domains'] ?? 1,
            'validated_at' => current_time('mysql'),
        ]);

        // Also store in settings for React app access
        $settings = get_option('trp_settings', []);
        $settings['license_key'] = $license_key;
        $settings['license_validated'] = true;
        update_option('trp_settings', $settings);

        return ['success' => true];
    }

    return ['success' => false, 'error' => $body['reason'] ?? 'Unknown error'];
}

// Deactivate license
function trp_deactivate_license() {
    $license_status = get_option('trp_license_status', []);
    $license_key = $license_status['license_key'] ?? '';

    if (empty($license_key)) {
        // Just clear local status
        delete_option('trp_license_status');
        return ['success' => true];
    }

    $domain = wp_parse_url(get_site_url(), PHP_URL_HOST);

    $response = wp_remote_post('https://www.vandromeda.com/api/license/deactivate.php', [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode([
            'license_key' => $license_key,
            'domain' => $domain,
        ]),
    ]);

    // Clear local status regardless of API response
    delete_option('trp_license_status');

    $settings = get_option('trp_settings', []);
    unset($settings['license_key']);
    unset($settings['license_validated']);
    update_option('trp_settings', $settings);

    if (is_wp_error($response)) {
        return ['success' => true]; // Still success locally
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    return ['success' => true];
}

// Periodically validate license (daily)
function trp_validate_license_periodically() {
    $license_status = get_option('trp_license_status', []);

    if (empty($license_status['is_pro']) || empty($license_status['license_key'])) {
        return;
    }

    // Check if validation needed (once per day)
    $last_validated = isset($license_status['validated_at']) ? strtotime($license_status['validated_at']) : 0;
    if ((time() - $last_validated) < DAY_IN_SECONDS) {
        return;
    }

    $domain = wp_parse_url(get_site_url(), PHP_URL_HOST);

    $response = wp_remote_post('https://www.vandromeda.com/api/license/validate.php', [
        'timeout' => 10,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode([
            'license_key' => $license_status['license_key'],
            'domain' => $domain,
        ]),
    ]);

    if (is_wp_error($response)) {
        return; // Don't invalidate on network error
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!empty($body['valid'])) {
        // Update validation timestamp
        $license_status['validated_at'] = current_time('mysql');
        $license_status['expires_at'] = $body['expiry_date'] ?? $license_status['expires_at'];
        update_option('trp_license_status', $license_status);
    } else {
        // License no longer valid - could be expired or revoked
        // Show admin notice but don't auto-deactivate
        set_transient('trp_license_invalid_notice', $body['reason'] ?? 'License validation failed', DAY_IN_SECONDS);
    }
}
add_action('admin_init', 'trp_validate_license_periodically');

// Show admin notice if license becomes invalid
function trp_license_admin_notices() {
    $notice = get_transient('trp_license_invalid_notice');
    if ($notice) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>' . esc_html__( 'Transit Route Planner:', 'transit-route-planner' ) . '</strong> ' . esc_html($notice) . ' ';
        echo '<a href="' . esc_url(admin_url('admin.php?page=trp-license')) . '">' . esc_html__( 'Check license status', 'transit-route-planner' ) . '</a></p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'trp_license_admin_notices');

// Exclude TRP scripts from LiteSpeed Cache JS delay/optimization
add_filter('script_loader_tag', function($tag, $handle) {
    if ($handle === 'trp-react-app') {
        return str_replace(' src=', ' data-no-optimize="1" src=', $tag);
    }
    return $tag;
}, 10, 2);