=== Transit Route Planner ===
Contributors: fullstackkev
Tags: transit, maps, route planner, google maps, directions
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 0.3.26
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Interactive transit route planner with Google Maps integration for WordPress. Plan routes with multiple travel modes.

== Description ==

Transit Route Planner brings powerful, interactive route planning to your WordPress site. Whether your visitors need to find public transit connections, driving directions, walking paths, or cycling routes, this plugin provides an intuitive interface powered by Google Maps.

= Key Features =

* **Interactive Route Planning** - Users can search for routes between any two locations with a clean, responsive interface
* **Google Maps Integration** - Powered by the reliable Google Maps JavaScript, Places, and Directions APIs
* **Location Autocomplete** - Smart autocomplete suggestions as users type, making location entry fast and accurate
* **Multiple Travel Modes** - Support for Transit, Driving, Walking, and Bicycling routes
* **Configurable Coverage Area** - Restrict autocomplete suggestions to your service area with rectangular bounds
* **Responsive Design** - Works beautifully on desktop and mobile devices
* **Simple Shortcode** - Add the route planner anywhere with `[transit_route_planner]`

= Free vs Pro =

**Free Tier (included):**
* Full route planning functionality
* 10 route calculations per day
* All travel modes
* Basic support

**Pro Upgrade (optional):**
* Unlimited route calculations
* Priority support
* Remove branding
* Multiple maps per page

Upgrade to Pro at [vandromeda.com/transit-route-planner](https://vandromeda.com/transit-route-planner/)

= Use Cases =

* Transit agencies displaying route options
* Tourism websites helping visitors navigate
* Event venues providing directions
* Business websites guiding customers
* Educational institutions assisting commuters

== Installation ==

1. Upload the `transit-route-planner` folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to **Settings > Transit Route Planner** to configure the plugin.
4. Enter your Google Maps API key (required - see FAQ for setup instructions).
5. Configure your default map center, zoom level, and coverage area.
6. Add the shortcode `[transit_route_planner]` to any page or post where you want the route planner to appear.

== Frequently Asked Questions ==

= How do I get a Google Maps API key? =

1. Go to the [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Navigate to APIs & Services > Library
4. Enable these APIs: Maps JavaScript API, Places API, Directions API
5. Go to APIs & Services > Credentials
6. Click "Create Credentials" > "API Key"
7. (Recommended) Restrict your API key to your website's domain for security

= Is a Google Maps API key required? =

Yes, a valid Google Maps API key is required for the plugin to function. Google offers a free tier with $200 monthly credit, which is typically enough for small to medium websites.

= What's the difference between Free and Pro? =

The free version includes full route planning functionality with a limit of 10 route calculations per day. The Pro version removes this limit and includes additional features like multiple maps per page, priority support, and branding removal.

= How do I upgrade to Pro? =

Visit [vandromeda.com/transit-route-planner](https://vandromeda.com/transit-route-planner/) to purchase a Pro license. After purchase, you'll receive a license key via email. Enter this key in the plugin settings under Settings > Transit Route Planner > License.

= Can I restrict the autocomplete to a specific area? =

Yes! In the plugin settings, you can configure a rectangular coverage area by setting corner coordinates. This limits autocomplete suggestions to your service region, improving the user experience for local route planning.

= Does this plugin track user data? =

The plugin sends route requests to Google Maps APIs to provide routing functionality. For Pro users, license validation requests are sent to the Vandromeda API (see Third-Party Services section for details). No personal user data is stored or tracked by the plugin itself.

== Screenshots ==

1. Frontend route planner with location inputs, travel mode selector, and interactive Google Map
2. Admin settings page showing API key management and security features
3. Full settings page with service area configuration and coverage options

== Changelog ==

= 0.3.24 =
* WordPress.org Plugin Check compliance
* Added internationalization (i18n) support
* Improved security with proper output escaping
* External admin JavaScript for better code organization
* Updated third-party services documentation

= 0.3.8 =
* Added automatic versioning system (version-bump.mjs, version-check.mjs)
* Added GitHub Actions for CI and auto-merge of claude/* branches
* Protected main branch with version policy enforcement

= 0.3.7 =
* Implemented rectangular location restriction for autocomplete (replaces circles/squares)
* Removed DynamicMapWithCirclesAndSquares component
* Renamed coverage area setting to "Rectangular Coverage Area"
* Fixed autocomplete to properly restrict results to configured bounds
* Added explicit corner coordinates support in PHP settings

= 0.3.6 =
* Added coverage area visualization settings
* Integrated Rectangle and DynamicMapWithCirclesAndSquares into MapContainer
* Updated coverage area colors (green rectangle, blue circles, purple squares)

= 0.3.5 =
* Added debug flags and password-protected API key editing
* Improved settings panel functionality

= 0.3.0 =
* Major refactoring and version sync across all files
* Standardized versioning in package.json, PHP plugin, and readme.txt

= 0.2.38 =
* License integration with Vandromeda API
* License validation, activation, and deactivation endpoints
* Free tier: 10 routes/day limit
* Pro tier: Unlimited routes
* Performance improvements and bug fixes

= 0.2.30 =
* REST API proxy endpoints for secure API key handling
* Improved admin settings page with quick start guide
* GitHub-based automatic update checking

= 0.1.45 =
* Initial release with transit/driving route planning
* Autocomplete for location inputs
* Admin settings configuration

== Upgrade Notice ==

= 0.3.24 =
Current stable release with rectangular coverage area support and license integration.

== Third-Party Services ==

This plugin connects to external third-party services to provide its functionality. By using this plugin, you acknowledge and agree to the terms of service of these providers:

= Google Maps Platform =

This plugin uses the following Google Maps APIs:

* **Maps JavaScript API** - Renders the interactive map
* **Places API** - Provides location autocomplete functionality
* **Directions API** - Calculates routes between locations

When users interact with the route planner, requests containing location data (addresses, coordinates) are sent to Google's servers.

* [Google Maps Platform Terms of Service](https://cloud.google.com/maps-platform/terms)
* [Google Privacy Policy](https://policies.google.com/privacy)

A Google Maps API key is required to use this plugin. You can obtain one at [Google Cloud Console](https://console.cloud.google.com/).

= Vandromeda API (License Validation) =

For Pro license validation, this plugin communicates with the Vandromeda API at `https://www.vandromeda.com/api/`.

**Data transmitted:**
* License key (when validating or activating a license)
* Website domain (to verify license is valid for your site)

**When data is sent:**
* When you enter or validate a license key in the plugin settings
* When activating or deactivating a Pro license
* Periodic license validation checks (once per day)

This data is used solely for license verification purposes and is not shared with third parties.

* [Vandromeda Terms of Service](https://vandromeda.com/terms/)
* [Vandromeda Privacy Policy](https://vandromeda.com/privacy/)

**Note:** The free version of this plugin does not require communication with Vandromeda API. License validation is only performed when a Pro license key is entered.
