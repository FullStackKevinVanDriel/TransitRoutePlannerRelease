# Transit Route Planner - WordPress.org Plugin Assets

This directory contains the required assets for WordPress.org plugin directory submission.

## Banner Images

Banner images appear at the top of your plugin's page on WordPress.org.

| File | Dimensions | Purpose |
|------|------------|---------|
| `banner-772x250.png` | 772 x 250 px | Standard resolution banner |
| `banner-1544x500.png` | 1544 x 500 px | Retina/HiDPI banner (2x) |

### Banner Design Recommendations

- Feature the map interface prominently
- Use transit-themed colors (blues, greens for routes)
- Include the plugin name or logo
- Show route lines or transit markers
- Keep text minimal and readable
- Avoid busy backgrounds that compete with the interface

## Icon Images

Icons appear in plugin listings and search results.

| File | Dimensions | Purpose |
|------|------------|---------|
| `icon-128x128.png` | 128 x 128 px | Standard resolution icon |
| `icon-256x256.png` | 256 x 256 px | Retina/HiDPI icon (2x) |

### Icon Design Recommendations

- Simple, recognizable design
- Works at small sizes
- Transit/map themed (route marker, bus/train icon, or map pin)
- Consider using a stylized route path or transit symbol
- Consistent with banner branding
- Avoid fine details that disappear at 128px

## Screenshots

Screenshots are referenced by number in `readme.txt` (e.g., `screenshot-1.png` corresponds to the first screenshot description).

| File | Description | Content |
|------|-------------|---------|
| `screenshot-1.png` | Frontend map interface | Show the public-facing map with route results displayed |
| `screenshot-2.png` | Admin settings page | Show the WordPress admin settings panel with configuration options |
| `screenshot-3.png` | License management panel | Show the license activation/management interface |

### Screenshot Requirements

- **Actual screenshots** - Must be real plugin screenshots, not mockups
- **Descriptive** - Show the feature being described in readme.txt
- **Clean** - Use a clean browser/admin theme
- **Focused** - Crop to show relevant content
- **Readable** - Text should be legible

### Screenshot Tips

1. Use a fresh WordPress installation for clean admin screenshots
2. Populate with realistic sample data
3. Capture at a reasonable resolution (width ~800-1200px recommended)
4. Remove any personal or sensitive information
5. Consider highlighting key features with annotations if needed

## File Format Specifications

- **Format:** PNG (required)
- **Optimization:** Compress for web without quality loss
- **Color Space:** sRGB
- **Transparency:** Supported but use solid backgrounds for banners

## Optimization Tools

Recommended tools for optimizing PNG files:
- [TinyPNG](https://tinypng.com/) - Online compression
- [ImageOptim](https://imageoptim.com/) - macOS app
- `pngquant` - Command line tool
- `optipng` - Command line tool

## Checklist Before Submission

- [ ] banner-772x250.png created and optimized
- [ ] banner-1544x500.png created and optimized
- [ ] icon-128x128.png created and optimized
- [ ] icon-256x256.png created and optimized
- [ ] screenshot-1.png shows frontend map interface
- [ ] screenshot-2.png shows admin settings
- [ ] screenshot-3.png shows license management
- [ ] All images are actual screenshots (not mockups)
- [ ] readme.txt screenshot descriptions match the images
- [ ] All files are PNG format
- [ ] All files are web-optimized

## Color Scheme Reference

For consistent branding, consider using:
- Primary: Transit blue (#0066CC or similar)
- Secondary: Route green (#28A745 or similar)
- Accent: Marker red (#DC3545 or similar)
- Background: Light gray (#F5F5F5) or white

## Directory Structure

```
assets/
├── README.md           (this file)
├── .gitkeep            (tracks empty directory)
├── banner-772x250.png  (to be created)
├── banner-1544x500.png (to be created)
├── icon-128x128.png    (to be created)
├── icon-256x256.png    (to be created)
├── screenshot-1.png    (to be created)
├── screenshot-2.png    (to be created)
└── screenshot-3.png    (to be created)
```
