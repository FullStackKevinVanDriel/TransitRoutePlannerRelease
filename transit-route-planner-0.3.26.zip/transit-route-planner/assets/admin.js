/**
 * Transit Route Planner Admin JavaScript
 * 
 * Uses trpAdmin object localized via wp_localize_script():
 * - trpAdmin.restUrl: REST API base URL
 * - trpAdmin.nonce: WP REST nonce
 */
var trpRestUrl = trpAdmin.restUrl;
var trpNonce = trpAdmin.nonce;

function trpSetPassword() {
    var password = document.getElementById('trp-new-password').value;
    var confirm = document.getElementById('trp-confirm-password').value;
    var status = document.getElementById('trp-password-status');

    if (password.length < 8) {
        status.innerHTML = '<span style="color: red;">Password must be at least 8 characters</span>';
        return;
    }

    if (password !== confirm) {
        status.innerHTML = '<span style="color: red;">Passwords do not match</span>';
        return;
    }

    status.innerHTML = 'Setting password...';

    fetch(trpRestUrl + 'set-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': trpNonce
        },
        body: JSON.stringify({ password: password })
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            status.innerHTML = '<span style="color: green;">Password set! Reloading...</span>';
            setTimeout(function() { location.reload(); }, 1000);
        } else {
            status.innerHTML = '<span style="color: red;">' + (data.message || 'Failed to set password') + '</span>';
        }
    })
    .catch(function(err) {
        status.innerHTML = '<span style="color: red;">Error: ' + err.message + '</span>';
    });
}

function trpUnlockApiKey() {
    var password = document.getElementById('trp-admin-password').value;
    var status = document.getElementById('trp-unlock-status');

    if (!password) {
        status.innerHTML = '<span style="color: red;">Please enter password</span>';
        return;
    }

    status.innerHTML = 'Verifying...';

    fetch(trpRestUrl + 'verify-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': trpNonce
        },
        body: JSON.stringify({ password: password })
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            status.innerHTML = '<span style="color: green;">Unlocked! Reloading...</span>';
            setTimeout(function() { location.reload(); }, 500);
        } else {
            status.innerHTML = '<span style="color: red;">Invalid password</span>';
        }
    })
    .catch(function(err) {
        status.innerHTML = '<span style="color: red;">Error: ' + err.message + '</span>';
    });
}

function trpLockApiKey() {
    fetch(trpRestUrl + 'lock-api-key', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': trpNonce
        }
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            location.reload();
        }
    });
}

function trpToggleKeyVisibility() {
    var input = document.getElementById('trp-api-key-input');
    if (input.type === 'password') {
        input.type = 'text';
    } else {
        input.type = 'password';
    }
}

function trpSetTestKey() {
    var testKey = document.getElementById('trp-test-api-key').value;
    var duration = document.getElementById('trp-test-duration').value;
    var status = document.getElementById('trp-test-key-status');

    if (!testKey) {
        status.innerHTML = '<span style="color: red;">Please enter a test API key</span>';
        return;
    }

    status.innerHTML = 'Activating...';

    fetch(trpRestUrl + 'set-test-key', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': trpNonce
        },
        body: JSON.stringify({ test_key: testKey, duration: parseInt(duration) })
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            status.innerHTML = '<span style="color: green;">Test key active for ' + data.duration_minutes + ' minutes! Reloading...</span>';
            setTimeout(function() { location.reload(); }, 1000);
        } else {
            status.innerHTML = '<span style="color: red;">' + (data.message || 'Failed to activate test key') + '</span>';
        }
    })
    .catch(function(err) {
        status.innerHTML = '<span style="color: red;">Error: ' + err.message + '</span>';
    });
}

function trpClearTestKey() {
    fetch(trpRestUrl + 'clear-test-key', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': trpNonce
        }
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            location.reload();
        }
    });
}

// Interactive Service Area Map
var trpBoundsMap = null;
var trpBoundsRect = null;

function trpInitBoundsMap() {
    var mapDiv = document.getElementById('trp-bounds-map');
    if (!mapDiv || typeof google === 'undefined' || typeof google.maps === 'undefined') {
        return;
    }

    // Get coordinates from inputs
    var nwLat = parseFloat(document.getElementById('trp_nw_lat').value) || 46.7667;
    var nwLng = parseFloat(document.getElementById('trp_nw_lng').value) || -123.2167;
    var neLat = parseFloat(document.getElementById('trp_ne_lat').value) || 46.7667;
    var neLng = parseFloat(document.getElementById('trp_ne_lng').value) || -121.3167;
    var swLat = parseFloat(document.getElementById('trp_sw_lat').value) || 46.3333;
    var swLng = parseFloat(document.getElementById('trp_sw_lng').value) || -123.2167;
    var seLat = parseFloat(document.getElementById('trp_se_lat').value) || 46.3333;
    var seLng = parseFloat(document.getElementById('trp_se_lng').value) || -121.3167;

    // Calculate center
    var centerLat = (nwLat + swLat) / 2;
    var centerLng = (nwLng + neLng) / 2;

    // Create map
    trpBoundsMap = new google.maps.Map(mapDiv, {
        center: { lat: centerLat, lng: centerLng },
        zoom: 8,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false
    });

    // Create editable rectangle
    var bounds = {
        north: nwLat,
        south: swLat,
        east: neLng,
        west: nwLng
    };

    trpBoundsRect = new google.maps.Rectangle({
        bounds: bounds,
        editable: true,
        draggable: true,
        strokeColor: '#2E7D32',
        strokeOpacity: 0.9,
        strokeWeight: 2,
        fillColor: '#4CAF50',
        fillOpacity: 0.15
    });
    trpBoundsRect.setMap(trpBoundsMap);

    // Fit map to bounds with padding
    trpBoundsMap.fitBounds(bounds, { top: 30, right: 30, bottom: 30, left: 30 });

    // Update inputs when rectangle changes
    google.maps.event.addListener(trpBoundsRect, 'bounds_changed', function() {
        var newBounds = trpBoundsRect.getBounds();
        var ne = newBounds.getNorthEast();
        var sw = newBounds.getSouthWest();

        document.getElementById('trp_nw_lat').value = ne.lat().toFixed(4);
        document.getElementById('trp_nw_lng').value = sw.lng().toFixed(4);
        document.getElementById('trp_ne_lat').value = ne.lat().toFixed(4);
        document.getElementById('trp_ne_lng').value = ne.lng().toFixed(4);
        document.getElementById('trp_sw_lat').value = sw.lat().toFixed(4);
        document.getElementById('trp_sw_lng').value = sw.lng().toFixed(4);
        document.getElementById('trp_se_lat').value = sw.lat().toFixed(4);
        document.getElementById('trp_se_lng').value = ne.lng().toFixed(4);
    });

    // Update rectangle when inputs change
    var coordInputs = ['trp_nw_lat', 'trp_nw_lng', 'trp_ne_lat', 'trp_ne_lng', 'trp_sw_lat', 'trp_sw_lng', 'trp_se_lat', 'trp_se_lng'];
    coordInputs.forEach(function(id) {
        var input = document.getElementById(id);
        if (input) {
            input.addEventListener('change', function() {
                var newBounds = {
                    north: parseFloat(document.getElementById('trp_nw_lat').value),
                    south: parseFloat(document.getElementById('trp_sw_lat').value),
                    east: parseFloat(document.getElementById('trp_ne_lng').value),
                    west: parseFloat(document.getElementById('trp_nw_lng').value)
                };
                trpBoundsRect.setBounds(newBounds);
                trpBoundsMap.fitBounds(newBounds, { top: 30, right: 30, bottom: 30, left: 30 });
            });
        }
    });
}

// Initialize map when Google Maps is ready
function trpWaitForGoogleMaps() {
    if (typeof google !== 'undefined' && typeof google.maps !== 'undefined' && typeof google.maps.Map === 'function') {
        trpInitBoundsMap();
    } else {
        setTimeout(trpWaitForGoogleMaps, 100);
    }
}

// Start waiting for Google Maps
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', trpWaitForGoogleMaps);
} else {
    trpWaitForGoogleMaps();
}

// AI Coordinate Lookup
var trpAiLocationsList = [];

function trpAiAddLocation() {
    var input = document.getElementById('trp-ai-query');
    var query = input.value.trim();
    if (!query) return;
    if (trpAiLocationsList.indexOf(query) === -1) {
        trpAiLocationsList.push(query);
        trpAiUpdateTags();
    }
    input.value = '';
    input.focus();
}

function trpAiRemoveLocation(index) {
    trpAiLocationsList.splice(index, 1);
    trpAiUpdateTags();
}

function trpAiUpdateTags() {
    var container = document.getElementById('trp-ai-tags');
    var listDiv = document.getElementById('trp-ai-locations');
    if (trpAiLocationsList.length === 0) {
        listDiv.classList.remove('has-locations');
        container.innerHTML = '';
        return;
    }
    listDiv.classList.add('has-locations');
    container.innerHTML = trpAiLocationsList.map(function(loc, i) {
        return '<span class="trp-ai-tag">' + loc + '<button type="button" onclick="trpAiRemoveLocation(' + i + ')">×</button></span>';
    }).join('');
}

function trpAiLookup() {
    var input = document.getElementById('trp-ai-query');
    var inputQuery = input.value.trim();
    var messages = document.getElementById('trp-ai-messages');
    var sendBtn = document.getElementById('trp-ai-send');
    var addBtn = document.getElementById('trp-ai-add');

    var locationsToLookup = [];
    if (trpAiLocationsList.length > 0) {
        locationsToLookup = trpAiLocationsList.slice();
        if (inputQuery && locationsToLookup.indexOf(inputQuery) === -1) {
            locationsToLookup.push(inputQuery);
        }
    } else if (inputQuery) {
        locationsToLookup.push(inputQuery);
    } else {
        return;
    }

    var userMsg = document.createElement('div');
    userMsg.className = 'trp-ai-msg trp-ai-user';
    userMsg.innerHTML = locationsToLookup.length > 1 ? '<strong>Combine:</strong> ' + locationsToLookup.join(', ') : locationsToLookup[0];
    messages.appendChild(userMsg);

    input.value = '';
    trpAiLocationsList = [];
    trpAiUpdateTags();
    sendBtn.disabled = true;
    addBtn.disabled = true;

    var typing = document.createElement('div');
    typing.className = 'trp-ai-msg trp-ai-assistant trp-ai-typing';
    typing.innerHTML = '<span></span><span></span><span></span>';
    messages.appendChild(typing);
    messages.scrollTop = messages.scrollHeight;

    if (locationsToLookup.length > 1) {
        trpAiLookupMultiple(locationsToLookup, messages, typing, sendBtn, addBtn);
    } else {
        trpAiLookupSingle(locationsToLookup[0], messages, typing, sendBtn, addBtn);
    }
}

function trpAiLookupSingle(query, messages, typing, sendBtn, addBtn) {
    fetch(trpRestUrl + 'ai-coordinates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': trpNonce },
        body: JSON.stringify({ query: query })
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        typing.remove();
        sendBtn.disabled = false;
        addBtn.disabled = false;
        if (data.success) {
            trpAiApplyCoordinates(data.coordinates);
            var successMsg = document.createElement('div');
            successMsg.className = 'trp-ai-msg trp-ai-assistant trp-ai-success';
            successMsg.innerHTML = '<strong>' + data.location + '</strong><br>Coordinates updated!';
            messages.appendChild(successMsg);
        } else {
            var errorMsg = document.createElement('div');
            errorMsg.className = 'trp-ai-msg trp-ai-assistant trp-ai-error';
            errorMsg.textContent = data.error || 'Failed to get coordinates';
            messages.appendChild(errorMsg);
        }
        messages.scrollTop = messages.scrollHeight;
    })
    .catch(function(err) {
        typing.remove();
        sendBtn.disabled = false;
        addBtn.disabled = false;
        var errorMsg = document.createElement('div');
        errorMsg.className = 'trp-ai-msg trp-ai-assistant trp-ai-error';
        errorMsg.textContent = 'Error: ' + err.message;
        messages.appendChild(errorMsg);
        messages.scrollTop = messages.scrollHeight;
    });
}

function trpAiLookupMultiple(locations, messages, typing, sendBtn, addBtn) {
    var promises = locations.map(function(loc) {
        return fetch(trpRestUrl + 'ai-coordinates', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': trpNonce },
            body: JSON.stringify({ query: loc })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) { return { location: loc, data: data }; })
        .catch(function(err) { return { location: loc, error: err.message }; });
    });

    Promise.all(promises).then(function(results) {
        typing.remove();
        sendBtn.disabled = false;
        addBtn.disabled = false;

        var errors = results.filter(function(r) { return r.error || !r.data.success; });
        var successes = results.filter(function(r) { return r.data && r.data.success; });

        if (successes.length === 0) {
            var errorMsg = document.createElement('div');
            errorMsg.className = 'trp-ai-msg trp-ai-assistant trp-ai-error';
            errorMsg.textContent = 'Failed to get coordinates for any location';
            messages.appendChild(errorMsg);
            messages.scrollTop = messages.scrollHeight;
            return;
        }

        var northLat = -90, southLat = 90, westLng = 180, eastLng = -180;
        var regionNames = [];
        successes.forEach(function(r) {
            var c = r.data.coordinates;
            regionNames.push(r.data.location || r.location);
            northLat = Math.max(northLat, c.nw_lat, c.ne_lat);
            southLat = Math.min(southLat, c.sw_lat, c.se_lat);
            westLng = Math.min(westLng, c.nw_lng, c.sw_lng);
            eastLng = Math.max(eastLng, c.ne_lng, c.se_lng);
        });

        var finalCoords = {
            nw_lat: northLat, nw_lng: westLng,
            ne_lat: northLat, ne_lng: eastLng,
            sw_lat: southLat, sw_lng: westLng,
            se_lat: southLat, se_lng: eastLng
        };

        trpAiApplyCoordinates(finalCoords);

        var successMsg = document.createElement('div');
        successMsg.className = 'trp-ai-msg trp-ai-assistant trp-ai-success';
        successMsg.innerHTML = '<strong>Combined Bounding Box</strong><br>' + regionNames.map(function(r) { return '• ' + r; }).join('<br>');
        if (errors.length > 0) {
            successMsg.innerHTML += '<br><small style="color:#d63638">Failed: ' + errors.map(function(e) { return e.location; }).join(', ') + '</small>';
        }
        messages.appendChild(successMsg);
        messages.scrollTop = messages.scrollHeight;
    });
}

function trpAiApplyCoordinates(coords) {
    document.getElementById('trp_nw_lat').value = coords.nw_lat.toFixed(6);
    document.getElementById('trp_nw_lng').value = coords.nw_lng.toFixed(6);
    document.getElementById('trp_ne_lat').value = coords.ne_lat.toFixed(6);
    document.getElementById('trp_ne_lng').value = coords.ne_lng.toFixed(6);
    document.getElementById('trp_sw_lat').value = coords.sw_lat.toFixed(6);
    document.getElementById('trp_sw_lng').value = coords.sw_lng.toFixed(6);
    document.getElementById('trp_se_lat').value = coords.se_lat.toFixed(6);
    document.getElementById('trp_se_lng').value = coords.se_lng.toFixed(6);

    if (trpBoundsRect && trpBoundsMap) {
        var newBounds = { north: coords.nw_lat, south: coords.sw_lat, east: coords.ne_lng, west: coords.nw_lng };
        trpBoundsRect.setBounds(newBounds);
        trpBoundsMap.fitBounds(newBounds, { top: 30, right: 30, bottom: 30, left: 30 });
    }
}
